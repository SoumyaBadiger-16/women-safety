export async function triggerEmergencyAlert(params: {
  userId: string
  alertType: string
  message?: string
  location?: { latitude: number; longitude: number }
}) {
  try {
    const response = await fetch("/api/emergency/send-alert", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(params),
    })

    const data = await response.json()

    if (!response.ok) {
      throw new Error(data.error || "Failed to send emergency alert")
    }

    console.log("[v0] Emergency alert sent successfully:", data)
    return data
  } catch (error) {
    console.error("[v0] Failed to trigger emergency alert:", error)
    throw error
  }
}

export function getCurrentLocation(): Promise<{ latitude: number; longitude: number }> {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error("Geolocation not supported"))
      return
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        resolve({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
        })
      },
      (error) => {
        reject(error)
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0,
      },
    )
  })
}
