"use client"

import type React from "react"
import { createContext, useContext, useState, useCallback, useEffect, useRef } from "react"
import { useContacts } from "./contacts-context"

interface SurvivorModeContextType {
  isSurvivorModeActive: boolean
  batteryLevel: number
  activateSurvivorMode: () => void
  deactivateSurvivorMode: () => void
  survivorStats: {
    locationUpdatesSent: number
    smsMessagesSent: number
    timeActive: number
    batteryAtStart: number
  }
}

const SurvivorModeContext = createContext<SurvivorModeContextType | undefined>(undefined)

export function SurvivorModeProvider({ children }: { children: React.ReactNode }) {
  const { contacts } = useContacts()
  const [isSurvivorModeActive, setIsSurvivorModeActive] = useState(false)
  const [batteryLevel, setBatteryLevel] = useState(100)
  const [survivorStats, setSurvivorStats] = useState({
    locationUpdatesSent: 0,
    smsMessagesSent: 0,
    timeActive: 0,
    batteryAtStart: 100,
  })

  const locationIntervalRef = useRef<NodeJS.Timeout | null>(null)
  const timerIntervalRef = useRef<NodeJS.Timeout | null>(null)
  const startTimeRef = useRef<Date | null>(null)
  const lastKnownLocationRef = useRef<{ latitude: number; longitude: number } | null>(null)

  // Monitor battery level
  useEffect(() => {
    const updateBattery = async () => {
      if ("getBattery" in navigator) {
        try {
          const battery = await (navigator as any).getBattery()
          setBatteryLevel(Math.round(battery.level * 100))

          battery.addEventListener("levelchange", () => {
            setBatteryLevel(Math.round(battery.level * 100))
          })
        } catch (error) {
          console.log("[v0] Battery API not available")
        }
      }
    }

    updateBattery()
  }, [])

  // Auto-activate when battery is critically low
  useEffect(() => {
    if (batteryLevel <= 5 && !isSurvivorModeActive) {
      console.log("[v0] Battery critically low - auto-activating Survivor Mode")
      activateSurvivorMode()
    }
  }, [batteryLevel])

  const sendLocationUpdate = useCallback(() => {
    if (typeof window === "undefined" || !navigator.geolocation) {
      console.log("[v0] Geolocation not available")
      return
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords

        // Cache the location
        lastKnownLocationRef.current = { latitude, longitude }

        // Get emergency contacts
        const emergencyContacts = contacts.filter((c) => c.notifyOnSOS)

        console.log("[v0] Survivor Mode - Sending location update:", {
          lat: latitude,
          lng: longitude,
          contacts: emergencyContacts.length,
        })

        // In a real app, this would send SMS via backend API
        const message = `SURVIVOR MODE ALERT: Battery critically low. Current location: https://maps.google.com/?q=${latitude},${longitude}`

        emergencyContacts.forEach((contact) => {
          console.log(`[v0] SMS to ${contact.phone}: ${message}`)
        })

        setSurvivorStats((prev) => ({
          ...prev,
          locationUpdatesSent: prev.locationUpdatesSent + 1,
          smsMessagesSent: prev.smsMessagesSent + emergencyContacts.length,
        }))
      },
      (error) => {
        console.log("[v0] Survivor Mode - Location error:", error.message)

        // Use last known location as fallback
        if (lastKnownLocationRef.current) {
          const { latitude, longitude } = lastKnownLocationRef.current
          const emergencyContacts = contacts.filter((c) => c.notifyOnSOS)

          console.log("[v0] Using cached location:", lastKnownLocationRef.current)

          const message = `SURVIVOR MODE ALERT: Battery critically low. Last known location: https://maps.google.com/?q=${latitude},${longitude}`

          emergencyContacts.forEach((contact) => {
            console.log(`[v0] SMS to ${contact.phone}: ${message}`)
          })

          setSurvivorStats((prev) => ({
            ...prev,
            locationUpdatesSent: prev.locationUpdatesSent + 1,
            smsMessagesSent: prev.smsMessagesSent + emergencyContacts.length,
          }))
        }
      },
      {
        enableHighAccuracy: false, // Low accuracy to save battery
        maximumAge: 120000, // Accept 2-minute old position
        timeout: 30000, // Increased to 30 seconds
      },
    )
  }, [contacts])

  const activateSurvivorMode = useCallback(() => {
    console.log("[v0] Activating Survivor Mode")

    // Record start state
    startTimeRef.current = new Date()
    setSurvivorStats((prev) => ({
      ...prev,
      batteryAtStart: batteryLevel,
      locationUpdatesSent: 0,
      smsMessagesSent: 0,
      timeActive: 0,
    }))

    // Reduce screen brightness (visual indication only in UI)
    if (typeof window !== "undefined") {
      document.body.style.filter = "brightness(0.3)"
    }

    // Send initial location
    sendLocationUpdate()

    // Send location updates every 2 minutes
    locationIntervalRef.current = setInterval(
      () => {
        sendLocationUpdate()
      },
      2 * 60 * 1000,
    ) // 2 minutes

    // Update timer every second
    timerIntervalRef.current = setInterval(() => {
      if (startTimeRef.current) {
        const elapsed = Math.floor((Date.now() - startTimeRef.current.getTime()) / 1000)
        setSurvivorStats((prev) => ({ ...prev, timeActive: elapsed }))
      }
    }, 1000)

    setIsSurvivorModeActive(true)

    // Vibrate to confirm activation
    if (navigator.vibrate) {
      navigator.vibrate([200, 100, 200])
    }
  }, [batteryLevel, sendLocationUpdate])

  const deactivateSurvivorMode = useCallback(() => {
    console.log("[v0] Deactivating Survivor Mode")

    if (locationIntervalRef.current) {
      clearInterval(locationIntervalRef.current)
      locationIntervalRef.current = null
    }

    if (timerIntervalRef.current) {
      clearInterval(timerIntervalRef.current)
      timerIntervalRef.current = null
    }

    // Restore screen brightness
    if (typeof window !== "undefined") {
      document.body.style.filter = ""
    }

    setIsSurvivorModeActive(false)
    startTimeRef.current = null
  }, [])

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (locationIntervalRef.current) clearInterval(locationIntervalRef.current)
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current)
      if (typeof window !== "undefined") {
        document.body.style.filter = ""
      }
    }
  }, [])

  return (
    <SurvivorModeContext.Provider
      value={{
        isSurvivorModeActive,
        batteryLevel,
        activateSurvivorMode,
        deactivateSurvivorMode,
        survivorStats,
      }}
    >
      {children}
    </SurvivorModeContext.Provider>
  )
}

export function useSurvivorMode() {
  const context = useContext(SurvivorModeContext)
  if (!context) {
    throw new Error("useSurvivorMode must be used within a SurvivorModeProvider")
  }
  return context
}
