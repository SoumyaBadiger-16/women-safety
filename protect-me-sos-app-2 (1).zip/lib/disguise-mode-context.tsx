"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect, useRef, useCallback } from "react"
import { useVault } from "./vault-context"

interface DisguiseModeContextType {
  isDisguiseActive: boolean
  activateDisguiseMode: () => Promise<void>
  deactivateDisguiseMode: () => void
  disguiseSettings: {
    enableCamera: boolean
    enableMicrophone: boolean
    enableLocationTracking: boolean
    enableSOSFlashlight: boolean
    voiceKeyword: string
  }
  updateDisguiseSettings: (settings: Partial<DisguiseModeContextType["disguiseSettings"]>) => void
  disguiseStatus: {
    isRecording: boolean
    isListening: boolean
    locationUpdates: number
    flashBlinks: number
  }
}

const DisguiseModeContext = createContext<DisguiseModeContextType | undefined>(undefined)

export function DisguiseModeProvider({ children }: { children: React.ReactNode }) {
  const { startRecording, stopRecording } = useVault()

  const [isDisguiseActive, setIsDisguiseActive] = useState(false)
  const [disguiseSettings, setDisguiseSettings] = useState({
    enableCamera: true,
    enableMicrophone: true,
    enableLocationTracking: true,
    enableSOSFlashlight: true,
    voiceKeyword: "rescue me",
  })

  const [disguiseStatus, setDisguiseStatus] = useState({
    isRecording: false,
    isListening: false,
    locationUpdates: 0,
    flashBlinks: 0,
  })

  const voiceRecognitionRef = useRef<any>(null)
  const locationIntervalRef = useRef<NodeJS.Timeout | null>(null)
  const flashIntervalRef = useRef<NodeJS.Timeout | null>(null)
  const videoStreamRef = useRef<MediaStream | null>(null)

  // Activate Disguise Mode
  const activateDisguiseMode = useCallback(async () => {
    try {
      console.log("[v0] Activating Smart Disguise Mode")

      // Start camera recording if enabled
      if (disguiseSettings.enableCamera) {
        await startRecording("video")
        setDisguiseStatus((prev) => ({ ...prev, isRecording: true }))
      }

      // Start voice keyword listening if enabled
      if (disguiseSettings.enableMicrophone && typeof window !== "undefined") {
        const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition
        if (SpeechRecognition) {
          const recognition = new SpeechRecognition()
          recognition.continuous = true
          recognition.interimResults = true
          recognition.lang = "en-US"

          recognition.onresult = (event: any) => {
            const last = event.results[event.results.length - 1]
            const transcript = last[0].transcript.toLowerCase().trim()

            if (transcript.includes(disguiseSettings.voiceKeyword.toLowerCase())) {
              console.log("[v0] Voice keyword detected in disguise mode - triggering SOS")
              // Trigger SOS
              deactivateDisguiseMode()
            }
          }

          recognition.onstart = () => {
            setDisguiseStatus((prev) => ({ ...prev, isListening: true }))
          }

          recognition.onend = () => {
            if (isDisguiseActive) {
              setTimeout(() => {
                try {
                  recognition.start()
                } catch {}
              }, 100)
            }
          }

          voiceRecognitionRef.current = recognition
          recognition.start()
        }
      }

      // Start location tracking if enabled
      if (disguiseSettings.enableLocationTracking) {
        locationIntervalRef.current = setInterval(() => {
          navigator.geolocation.getCurrentPosition(
            (position) => {
              console.log("[v0] Disguise mode location update:", {
                lat: position.coords.latitude,
                lng: position.coords.longitude,
              })
              setDisguiseStatus((prev) => ({ ...prev, locationUpdates: prev.locationUpdates + 1 }))
            },
            () => {},
            { enableHighAccuracy: true },
          )
        }, 120000) // Every 2 minutes
      }

      // Start SOS flashlight blinking if enabled
      if (disguiseSettings.enableSOSFlashlight) {
        // SOS pattern in Morse code: · · · − − − · · · (3 short, 3 long, 3 short)
        const sosPattern = [200, 200, 200, 200, 200, 200, 600, 200, 600, 200, 600, 200, 200, 200, 200, 200, 200]
        let patternIndex = 0

        const blinkSOS = async () => {
          try {
            const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } })
            const track = stream.getVideoTracks()[0]

            // @ts-ignore - ImageCapture API
            if (track && typeof track.applyConstraints === "function") {
              flashIntervalRef.current = setInterval(async () => {
                const duration = sosPattern[patternIndex % sosPattern.length]

                // Flash on
                await track.applyConstraints({ advanced: [{ torch: true } as any] })

                setTimeout(async () => {
                  // Flash off
                  await track.applyConstraints({ advanced: [{ torch: false } as any] })
                }, duration)

                patternIndex++
                setDisguiseStatus((prev) => ({ ...prev, flashBlinks: prev.flashBlinks + 1 }))
              }, 1000)
            }
          } catch (error) {
            console.log("[v0] Flashlight not available on this device")
          }
        }

        blinkSOS()
      }

      setIsDisguiseActive(true)
    } catch (error) {
      console.error("[v0] Failed to activate disguise mode:", error)
    }
  }, [disguiseSettings, startRecording])

  // Deactivate Disguise Mode
  const deactivateDisguiseMode = useCallback(() => {
    console.log("[v0] Deactivating Smart Disguise Mode")

    // Stop recording
    if (disguiseStatus.isRecording) {
      stopRecording()
    }

    // Stop voice recognition
    if (voiceRecognitionRef.current) {
      voiceRecognitionRef.current.stop()
      voiceRecognitionRef.current = null
    }

    // Stop location tracking
    if (locationIntervalRef.current) {
      clearInterval(locationIntervalRef.current)
      locationIntervalRef.current = null
    }

    // Stop flashlight
    if (flashIntervalRef.current) {
      clearInterval(flashIntervalRef.current)
      flashIntervalRef.current = null
    }

    // Stop video stream
    if (videoStreamRef.current) {
      videoStreamRef.current.getTracks().forEach((track) => track.stop())
      videoStreamRef.current = null
    }

    setIsDisguiseActive(false)
    setDisguiseStatus({
      isRecording: false,
      isListening: false,
      locationUpdates: 0,
      flashBlinks: 0,
    })
  }, [disguiseStatus, stopRecording])

  // Update settings
  const updateDisguiseSettings = useCallback((settings: Partial<typeof disguiseSettings>) => {
    setDisguiseSettings((prev) => ({ ...prev, ...settings }))
  }, [])

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (isDisguiseActive) {
        deactivateDisguiseMode()
      }
    }
  }, [isDisguiseActive, deactivateDisguiseMode])

  return (
    <DisguiseModeContext.Provider
      value={{
        isDisguiseActive,
        activateDisguiseMode,
        deactivateDisguiseMode,
        disguiseSettings,
        updateDisguiseSettings,
        disguiseStatus,
      }}
    >
      {children}
    </DisguiseModeContext.Provider>
  )
}

export function useDisguiseMode() {
  const context = useContext(DisguiseModeContext)
  if (!context) {
    throw new Error("useDisguiseMode must be used within a DisguiseModeProvider")
  }
  return context
}
