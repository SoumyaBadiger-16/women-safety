"use client"

import type React from "react"
import { createContext, useContext, useState, useCallback, useRef, useEffect } from "react"

interface GestureDetectionContextType {
  isGestureDetectionActive: boolean
  startGestureDetection: () => Promise<void>
  stopGestureDetection: () => void
  gestureSettings: {
    enableCircleGesture: boolean
    enableZGesture: boolean
    enableSOSGesture: boolean
    sensitivity: number
  }
  updateGestureSettings: (settings: Partial<GestureDetectionContextType["gestureSettings"]>) => void
  detectedGestures: string[]
  lastGestureTime: Date | null
}

const GestureDetectionContext = createContext<GestureDetectionContextType | undefined>(undefined)

export function GestureDetectionProvider({ children }: { children: React.ReactNode }) {
  const [isGestureDetectionActive, setIsGestureDetectionActive] = useState(false)
  const [gestureSettings, setGestureSettings] = useState({
    enableCircleGesture: true,
    enableZGesture: true,
    enableSOSGesture: true,
    sensitivity: 0.7,
  })
  const [detectedGestures, setDetectedGestures] = useState<string[]>([])
  const [lastGestureTime, setLastGestureTime] = useState<Date | null>(null)

  const videoRef = useRef<HTMLVideoElement | null>(null)
  const canvasRef = useRef<HTMLCanvasElement | null>(null)
  const animationFrameRef = useRef<number | null>(null)
  const streamRef = useRef<MediaStream | null>(null)

  // Simple hand tracking using motion detection
  const detectMotion = useCallback((context: CanvasRenderingContext2D, width: number, height: number) => {
    const imageData = context.getImageData(0, 0, width, height)
    const pixels = imageData.data

    let motionPixels = 0
    let totalBrightness = 0

    for (let i = 0; i < pixels.length; i += 4) {
      const r = pixels[i]
      const g = pixels[i + 1]
      const b = pixels[i + 2]
      const brightness = (r + g + b) / 3

      totalBrightness += brightness
      if (brightness > 100) {
        motionPixels++
      }
    }

    return {
      motionPercentage: (motionPixels / (pixels.length / 4)) * 100,
      avgBrightness: totalBrightness / (pixels.length / 4),
    }
  }, [])

  // Track motion patterns to detect gestures
  const motionHistoryRef = useRef<number[]>([])

  const analyzeGesture = useCallback(
    (motionData: { motionPercentage: number; avgBrightness: number }) => {
      motionHistoryRef.current.push(motionData.motionPercentage)

      // Keep only last 30 frames
      if (motionHistoryRef.current.length > 30) {
        motionHistoryRef.current.shift()
      }

      // Need at least 20 frames to detect a pattern
      if (motionHistoryRef.current.length < 20) return null

      const history = motionHistoryRef.current
      const recentAvg = history.slice(-10).reduce((a, b) => a + b, 0) / 10
      const olderAvg = history.slice(0, 10).reduce((a, b) => a + b, 0) / 10

      // Detect circular motion (consistent medium motion)
      if (gestureSettings.enableCircleGesture) {
        const variance = history.reduce((sum, val) => sum + Math.abs(val - recentAvg), 0) / history.length
        if (recentAvg > 15 && recentAvg < 40 && variance < 5) {
          return "circle"
        }
      }

      // Detect Z motion (sharp changes)
      if (gestureSettings.enableZGesture) {
        const changes = history.slice(1).map((val, i) => Math.abs(val - history[i]))
        const avgChange = changes.reduce((a, b) => a + b, 0) / changes.length
        if (avgChange > 10 && recentAvg > 20) {
          return "z"
        }
      }

      // Detect SOS pattern (3 quick, 3 slow, 3 quick motions)
      if (gestureSettings.enableSOSGesture) {
        // Simplified: detect repeated quick motions
        const peaks = history.filter((v) => v > 25).length
        if (peaks > 15 && recentAvg > 20) {
          return "sos"
        }
      }

      return null
    },
    [gestureSettings],
  )

  const startGestureDetection = useCallback(async () => {
    try {
      // Request camera access with front camera
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user", width: 320, height: 240 },
        audio: false,
      })

      streamRef.current = stream

      // Create hidden video element
      if (!videoRef.current) {
        videoRef.current = document.createElement("video")
        videoRef.current.autoplay = true
        videoRef.current.playsInline = true
        videoRef.current.muted = true
      }

      videoRef.current.srcObject = stream

      // Create hidden canvas for processing
      if (!canvasRef.current) {
        canvasRef.current = document.createElement("canvas")
      }

      await new Promise((resolve) => {
        if (videoRef.current) {
          videoRef.current.onloadedmetadata = resolve
        }
      })

      const video = videoRef.current
      const canvas = canvasRef.current
      const context = canvas.getContext("2d")

      if (!context || !video) return

      canvas.width = video.videoWidth
      canvas.height = video.videoHeight

      let lastGestureDetected: string | null = null
      let gestureConfirmCount = 0

      const processFrame = () => {
        if (!isGestureDetectionActive) return

        context.drawImage(video, 0, 0, canvas.width, canvas.height)

        const motionData = detectMotion(context, canvas.width, canvas.height)
        const gesture = analyzeGesture(motionData)

        if (gesture) {
          if (gesture === lastGestureDetected) {
            gestureConfirmCount++
            if (gestureConfirmCount >= 3) {
              // Confirmed gesture
              console.log("[v0] AirDraw SOS gesture detected:", gesture)
              setDetectedGestures((prev) => [...prev.slice(-9), gesture])
              setLastGestureTime(new Date())

              // Get current location and send real alert
              import("@/lib/emergency-utils").then(async ({ triggerEmergencyAlert, getCurrentLocation }) => {
                try {
                  const location = await getCurrentLocation()
                  const userId = localStorage.getItem("userId") || ""

                  await triggerEmergencyAlert({
                    userId,
                    alertType: "air-gesture",
                    message: `Emergency SOS triggered by air gesture (${gesture})`,
                    location,
                  })
                } catch (error) {
                  console.error("[v0] Failed to send air gesture alert:", error)
                }
              })

              // Reset
              lastGestureDetected = null
              gestureConfirmCount = 0
              motionHistoryRef.current = []
            }
          } else {
            lastGestureDetected = gesture
            gestureConfirmCount = 1
          }
        }

        animationFrameRef.current = requestAnimationFrame(processFrame)
      }

      setIsGestureDetectionActive(true)
      processFrame()
    } catch (error) {
      console.error("[v0] Failed to start gesture detection:", error)
      alert("Could not access camera for gesture detection. Please grant camera permissions.")
    }
  }, [detectMotion, analyzeGesture, isGestureDetectionActive])

  const stopGestureDetection = useCallback(() => {
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current)
    }

    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop())
      streamRef.current = null
    }

    setIsGestureDetectionActive(false)
    motionHistoryRef.current = []
  }, [])

  const updateGestureSettings = useCallback((settings: Partial<typeof gestureSettings>) => {
    setGestureSettings((prev) => ({ ...prev, ...settings }))
  }, [])

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopGestureDetection()
    }
  }, [stopGestureDetection])

  return (
    <GestureDetectionContext.Provider
      value={{
        isGestureDetectionActive,
        startGestureDetection,
        stopGestureDetection,
        gestureSettings,
        updateGestureSettings,
        detectedGestures,
        lastGestureTime,
      }}
    >
      {children}
    </GestureDetectionContext.Provider>
  )
}

export function useGestureDetection() {
  const context = useContext(GestureDetectionContext)
  if (!context) {
    throw new Error("useGestureDetection must be used within a GestureDetectionProvider")
  }
  return context
}
