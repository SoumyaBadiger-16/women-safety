"use client"

import type React from "react"
import { createContext, useContext, useState, useCallback, useEffect, useRef } from "react"

interface ThreatPattern {
  type: "speed-change" | "route-deviation" | "isolated-area" | "unusual-timing" | "prolonged-stop"
  severity: "low" | "medium" | "high"
  message: string
  timestamp: Date
}

interface ThreatSenseContextType {
  isThreatSenseActive: boolean
  startThreatSense: () => void
  stopThreatSense: () => void
  currentThreatLevel: "safe" | "caution" | "danger"
  recentThreats: ThreatPattern[]
  userBehaviorProfile: {
    avgWalkingSpeed: number
    usualRoutes: string[]
    typicalTravelTimes: string[]
    safeZones: Array<{ lat: number; lng: number; radius: number }>
  }
}

const ThreatSenseContext = createContext<ThreatSenseContextType | undefined>(undefined)

export function ThreatSenseProvider({ children }: { children: React.ReactNode }) {
  const [isThreatSenseActive, setIsThreatSenseActive] = useState(false)
  const [currentThreatLevel, setCurrentThreatLevel] = useState<"safe" | "caution" | "danger">("safe")
  const [recentThreats, setRecentThreats] = useState<ThreatPattern[]>([])
  const [userBehaviorProfile, setUserBehaviorProfile] = useState({
    avgWalkingSpeed: 1.4, // meters per second (normal walking speed)
    usualRoutes: [],
    typicalTravelTimes: ["08:00-10:00", "17:00-19:00"],
    safeZones: [],
  })

  const locationHistoryRef = useRef<Array<{ lat: number; lng: number; timestamp: Date; speed: number }>>([])
  const monitoringIntervalRef = useRef<NodeJS.Timeout | null>(null)
  const lastLocationRef = useRef<{ lat: number; lng: number; timestamp: Date } | null>(null)

  // Calculate distance between two coordinates (Haversine formula)
  const calculateDistance = useCallback((lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 6371e3 // Earth radius in meters
    const φ1 = (lat1 * Math.PI) / 180
    const φ2 = (lat2 * Math.PI) / 180
    const Δφ = ((lat2 - lat1) * Math.PI) / 180
    const Δλ = ((lon2 - lon1) * Math.PI) / 180

    const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) + Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2)

    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))

    return R * c
  }, [])

  // Analyze location patterns for threats
  const analyzeThreatPatterns = useCallback(
    (currentLocation: { lat: number; lng: number; speed: number }) => {
      const threats: ThreatPattern[] = []

      // Check speed deviation (panic pace or unusually slow)
      if (currentLocation.speed > userBehaviorProfile.avgWalkingSpeed * 2) {
        threats.push({
          type: "speed-change",
          severity: "high",
          message: "Unusual fast movement detected - possible panic situation",
          timestamp: new Date(),
        })
      } else if (currentLocation.speed > userBehaviorProfile.avgWalkingSpeed * 1.5) {
        threats.push({
          type: "speed-change",
          severity: "medium",
          message: "Walking faster than normal - monitoring situation",
          timestamp: new Date(),
        })
      }

      // Check if in isolated area (simplified: far from safe zones)
      if (userBehaviorProfile.safeZones.length > 0) {
        const nearSafeZone = userBehaviorProfile.safeZones.some((zone) => {
          const distance = calculateDistance(currentLocation.lat, currentLocation.lng, zone.lat, zone.lng)
          return distance < zone.radius
        })

        if (!nearSafeZone) {
          threats.push({
            type: "isolated-area",
            severity: "medium",
            message: "You are in an unfamiliar area - stay alert",
            timestamp: new Date(),
          })
        }
      }

      // Check for prolonged stops
      if (locationHistoryRef.current.length > 5) {
        const recentLocations = locationHistoryRef.current.slice(-5)
        const totalMovement = recentLocations.reduce((sum, loc, i) => {
          if (i === 0) return 0
          const prev = recentLocations[i - 1]
          return sum + calculateDistance(loc.lat, loc.lng, prev.lat, prev.lng)
        }, 0)

        if (totalMovement < 10) {
          // Less than 10 meters in last 5 updates
          threats.push({
            type: "prolonged-stop",
            severity: "medium",
            message: "Staying in one place for unusual duration",
            timestamp: new Date(),
          })
        }
      }

      // Check unusual timing
      const currentHour = new Date().getHours()
      const isLateNight = currentHour >= 22 || currentHour <= 5
      if (isLateNight) {
        threats.push({
          type: "unusual-timing",
          severity: "low",
          message: "Traveling during late hours - extra caution advised",
          timestamp: new Date(),
        })
      }

      return threats
    },
    [userBehaviorProfile, calculateDistance],
  )

  // Monitor location and detect threats
  const monitorLocation = useCallback(() => {
    if (!navigator.geolocation) return

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude, speed } = position.coords
        const currentSpeed = speed || 0

        const currentLocation = {
          lat: latitude,
          lng: longitude,
          speed: currentSpeed,
        }

        // Add to history
        locationHistoryRef.current.push({
          ...currentLocation,
          timestamp: new Date(),
        })

        // Keep only last 20 locations
        if (locationHistoryRef.current.length > 20) {
          locationHistoryRef.current = locationHistoryRef.current.slice(-20)
        }

        // Analyze for threats
        const detectedThreats = analyzeThreatPatterns(currentLocation)

        if (detectedThreats.length > 0) {
          setRecentThreats((prev) => [...detectedThreats, ...prev].slice(0, 10))

          // Determine overall threat level
          const highSeverity = detectedThreats.some((t) => t.severity === "high")
          const mediumSeverity = detectedThreats.some((t) => t.severity === "medium")

          if (highSeverity) {
            setCurrentThreatLevel("danger")
            // Show warning notification
            if ("Notification" in window && Notification.permission === "granted") {
              new Notification("⚠️ Danger Detected", {
                body: detectedThreats.find((t) => t.severity === "high")?.message || "Unusual pattern detected",
                tag: "threat-alert",
              })
            }
          } else if (mediumSeverity) {
            setCurrentThreatLevel("caution")
          } else {
            setCurrentThreatLevel("safe")
          }

          console.log("[v0] ThreatSense - Threats detected:", detectedThreats)
        } else {
          setCurrentThreatLevel("safe")
        }

        lastLocationRef.current = { lat: latitude, lng: longitude, timestamp: new Date() }
      },
      (error) => {
        console.error("[v0] ThreatSense - Location error:", error)
      },
      {
        enableHighAccuracy: true,
        maximumAge: 5000,
        timeout: 10000,
      },
    )
  }, [analyzeThreatPatterns])

  const startThreatSense = useCallback(() => {
    console.log("[v0] Starting ThreatSense AI monitoring")

    // Request notification permission
    if ("Notification" in window && Notification.permission === "default") {
      Notification.requestPermission()
    }

    // Start monitoring
    monitorLocation()
    monitoringIntervalRef.current = setInterval(monitorLocation, 10000) // Every 10 seconds

    setIsThreatSenseActive(true)
  }, [monitorLocation])

  const stopThreatSense = useCallback(() => {
    console.log("[v0] Stopping ThreatSense AI monitoring")

    if (monitoringIntervalRef.current) {
      clearInterval(monitoringIntervalRef.current)
      monitoringIntervalRef.current = null
    }

    setIsThreatSenseActive(false)
    setCurrentThreatLevel("safe")
    locationHistoryRef.current = []
  }, [])

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (monitoringIntervalRef.current) {
        clearInterval(monitoringIntervalRef.current)
      }
    }
  }, [])

  return (
    <ThreatSenseContext.Provider
      value={{
        isThreatSenseActive,
        startThreatSense,
        stopThreatSense,
        currentThreatLevel,
        recentThreats,
        userBehaviorProfile,
      }}
    >
      {children}
    </ThreatSenseContext.Provider>
  )
}

export function useThreatSense() {
  const context = useContext(ThreatSenseContext)
  if (!context) {
    throw new Error("useThreatSense must be used within a ThreatSenseProvider")
  }
  return context
}
