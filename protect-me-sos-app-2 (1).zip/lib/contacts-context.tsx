"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"
import { sendOfflineSMS } from "@/lib/offline-manager"
import { createClient } from "@/lib/supabase/client"
import { useAuth } from "@/lib/auth-context"

export interface Contact {
  id: string
  name: string
  phone: string
  email?: string
  relationship: string
  isPrimary: boolean
  notifyOnSOS: boolean
  shareLocation: boolean
  createdAt: Date
  isPoliceStation?: boolean
  isEmergencyService?: boolean
  distance?: string
}

interface SOSSession {
  sessionId: string
  isActive: boolean
  startTime: Date
  contacts: Contact[]
}

interface ContactsContextType {
  contacts: Contact[]
  addContact: (contact: Omit<Contact, "id" | "createdAt">) => void
  updateContact: (id: string, contact: Partial<Contact>) => void
  deleteContact: (id: string) => void
  setPrimaryContact: (id: string) => void
  importFromPhone: () => Promise<void>
  addNearbyPoliceStations: (lat: number, lng: number) => Promise<void>
  sendSOSAlerts: (location: { lat: number; lng: number; address: string }) => Promise<{
    sent: Contact[]
    failed: Contact[]
    sessionId: string
  }>
  updateSOSLocation: (sessionId: string, location: { lat: number; lng: number; address: string }) => Promise<void>
  endSOSSession: (sessionId: string) => Promise<void>
  currentSOSSession: SOSSession | null
  sendOfflineSOSToAll: (location?: { lat: number; lng: number; address?: string }) => Promise<void>
}

const ContactsContext = createContext<ContactsContextType | undefined>(undefined)

const defaultContacts: Contact[] = [
  {
    id: "1",
    name: "Mom",
    phone: "+17813680539",
    relationship: "Parent",
    isPrimary: true,
    notifyOnSOS: true,
    shareLocation: true,
    createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
  },
  {
    id: "2",
    name: "Dad",
    phone: "+919741589059",
    relationship: "Parent",
    isPrimary: false,
    notifyOnSOS: true,
    shareLocation: true,
    createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
  },
  {
    id: "3",
    name: "Best Friend",
    phone: "+918050253556",
    relationship: "Friend",
    isPrimary: false,
    notifyOnSOS: true,
    shareLocation: false,
    createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
  },
]

const DB_NAME = "ProtectMeContactsDB"
const DB_VERSION = 1

function openContactsDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION)
    request.onerror = () => reject(request.error)
    request.onsuccess = () => resolve(request.result)
    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result
      if (!db.objectStoreNames.contains("contacts")) {
        db.createObjectStore("contacts", { keyPath: "id" })
      }
    }
  })
}

async function saveContactsToIndexedDB(contacts: Contact[]) {
  try {
    const db = await openContactsDB()
    const tx = db.transaction("contacts", "readwrite")
    const store = tx.objectStore("contacts")
    store.clear()
    contacts.forEach((contact) => store.put(contact))
  } catch (e) {
    console.error("Failed to save to IndexedDB:", e)
  }
}

async function loadContactsFromIndexedDB(): Promise<Contact[]> {
  try {
    const db = await openContactsDB()
    const tx = db.transaction("contacts", "readonly")
    const store = tx.objectStore("contacts")
    const request = store.getAll()
    return new Promise((resolve, reject) => {
      request.onsuccess = () => resolve(request.result || [])
      request.onerror = () => reject(request.error)
    })
  } catch (e) {
    return []
  }
}

export function ContactsProvider({ children }: { children: React.ReactNode }) {
  const [contacts, setContacts] = useState<Contact[]>([])
  const [currentSOSSession, setCurrentSOSSession] = useState<SOSSession | null>(null)
  const [isOnline, setIsOnline] = useState(true)
  const { user } = useAuth()
  const supabase = createClient()

  useEffect(() => {
    if (!user) return

    const loadContacts = async () => {
      const { data, error } = await supabase
        .from("emergency_contacts")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })

      if (data && !error) {
        const mappedContacts: Contact[] = data.map((c) => ({
          id: c.id,
          name: c.name,
          phone: c.phone,
          email: c.email || undefined,
          relationship: c.relationship || "Friend",
          isPrimary: c.is_primary || false,
          notifyOnSOS: c.notify_on_sos || false,
          shareLocation: true,
          createdAt: new Date(c.created_at),
        }))
        setContacts(mappedContacts)
      }
    }

    loadContacts()

    // Track online status
    setIsOnline(navigator.onLine)
    const handleOnline = () => setIsOnline(true)
    const handleOffline = () => setIsOnline(false)
    window.addEventListener("online", handleOnline)
    window.addEventListener("offline", handleOffline)

    return () => {
      window.removeEventListener("online", handleOnline)
      window.removeEventListener("offline", handleOffline)
    }
  }, [user, supabase])

  const addContact = async (contact: Omit<Contact, "id" | "createdAt">) => {
    if (!user) return

    const { data, error } = await supabase
      .from("emergency_contacts")
      .insert({
        user_id: user.id,
        name: contact.name,
        phone: contact.phone,
        email: contact.email,
        relationship: contact.relationship,
        is_primary: contact.isPrimary,
        notify_on_sos: contact.notifyOnSOS,
        notify_on_check_in: false,
      })
      .select()
      .single()

    if (data && !error) {
      const newContact: Contact = {
        id: data.id,
        name: data.name,
        phone: data.phone,
        email: data.email || undefined,
        relationship: data.relationship,
        isPrimary: data.is_primary,
        notifyOnSOS: data.notify_on_sos,
        shareLocation: true,
        createdAt: new Date(data.created_at),
      }
      setContacts([...contacts, newContact])
    }
  }

  const updateContact = async (id: string, updates: Partial<Contact>) => {
    if (!user) return

    const { error } = await supabase
      .from("emergency_contacts")
      .update({
        name: updates.name,
        phone: updates.phone,
        email: updates.email,
        relationship: updates.relationship,
        is_primary: updates.isPrimary,
        notify_on_sos: updates.notifyOnSOS,
      })
      .eq("id", id)
      .eq("user_id", user.id)

    if (!error) {
      setContacts(contacts.map((c) => (c.id === id ? { ...c, ...updates } : c)))
    }
  }

  const deleteContact = async (id: string) => {
    if (!user) return

    const { error } = await supabase.from("emergency_contacts").delete().eq("id", id).eq("user_id", user.id)

    if (!error) {
      setContacts(contacts.filter((c) => c.id !== id))
    }
  }

  const setPrimaryContact = async (id: string) => {
    if (!user) return

    // First, unset all primary contacts
    await supabase.from("emergency_contacts").update({ is_primary: false }).eq("user_id", user.id)

    // Then set the selected one as primary
    await supabase.from("emergency_contacts").update({ is_primary: true }).eq("id", id).eq("user_id", user.id)

    setContacts(contacts.map((c) => ({ ...c, isPrimary: c.id === id })))
  }

  const importFromPhone = async () => {
    try {
      if ("contacts" in navigator && "ContactsManager" in window) {
        const props = ["name", "email", "tel"]
        const opts = { multiple: true }
        // @ts-ignore
        const selectedContacts = await navigator.contacts.select(props, opts)

        if (selectedContacts && selectedContacts.length > 0) {
          for (const contact of selectedContacts) {
            await addContact({
              name: contact.name?.[0] || "Unknown",
              phone: contact.tel?.[0] || "",
              email: contact.email?.[0] || "",
              relationship: "Friend",
              isPrimary: false,
              notifyOnSOS: true,
              shareLocation: false,
            })
          }
        }
      } else {
        alert("Contact Picker not supported. Please add contacts manually.")
      }
    } catch (error) {
      console.error("Contact import error:", error)
    }
  }

  const addNearbyPoliceStations = async (lat: number, lng: number) => {
    try {
      const response = await fetch(`/api/nearby-police?lat=${lat}&lng=${lng}`)
      const data = await response.json()

      if (data.success && data.policeStations && data.policeStations.length > 0) {
        for (const station of data.policeStations) {
          await addContact({
            name: station.name,
            phone: station.phone,
            relationship: "Police Station",
            isPrimary: false,
            notifyOnSOS: true,
            shareLocation: true,
          })
        }

        if (data.emergencyServices) {
          for (const svc of data.emergencyServices.filter((s: any) => s.type === "police")) {
            await addContact({
              name: svc.name,
              phone: svc.phone,
              relationship: "Emergency Service",
              isPrimary: false,
              notifyOnSOS: true,
              shareLocation: true,
            })
          }
        }
      }
    } catch (error) {
      console.error("Failed to fetch police stations:", error)
      await addContact({
        name: "Whitefield Police Station",
        phone: "080-28452317",
        relationship: "Police Station",
        isPrimary: false,
        notifyOnSOS: true,
        shareLocation: true,
      })

      await addContact({
        name: "Emergency Police (100)",
        phone: "100",
        relationship: "Emergency Service",
        isPrimary: false,
        notifyOnSOS: true,
        shareLocation: true,
      })
    }
  }

  const sendOfflineSOSToAll = async (location?: { lat: number; lng: number; address?: string }) => {
    const sosContacts = contacts.filter((c) => c.notifyOnSOS)

    const locationText = location
      ? `\n\nMy Location: ${location.address || `${location.lat}, ${location.lng}`}\nGoogle Maps: https://maps.google.com/?q=${location.lat},${location.lng}`
      : ""

    const message = `EMERGENCY SOS!\n\nI need immediate help! This is an emergency alert.${locationText}\n\nPlease call me or come to my location immediately!\n\nSent from ProtectMe SOS App`

    for (const contact of sosContacts) {
      sendOfflineSMS(contact.phone, message)
      // Small delay between messages to prevent overload
      await new Promise((resolve) => setTimeout(resolve, 800))
    }
  }

  const sendSOSAlerts = async (location: { lat: number; lng: number; address: string }): Promise<{
    sent: Contact[]
    failed: Contact[]
    sessionId: string
  }> => {
    if (!user) {
      return { sent: [], failed: contacts, sessionId: "" }
    }

    const sosContacts = contacts.filter((c) => c.notifyOnSOS)
    const sent: Contact[] = []
    const failed: Contact[] = []

    const { data: alertData, error: alertError } = await supabase
      .from("sos_alerts")
      .insert({
        user_id: user.id,
        trigger_type: "manual",
        latitude: location.lat,
        longitude: location.lng,
        location_address: location.address,
        status: "active",
      })
      .select()
      .single()

    const sessionId = alertData?.id || crypto.randomUUID()

    const userName = contacts.find((c) => c.isPrimary)?.name || "ProtectMe User"
    const mapLink = `https://www.google.com/maps?q=${location.lat},${location.lng}`
    const liveTrackLink = `https://www.google.com/maps/@${location.lat},${location.lng},18z`

    const message = `🚨 *EMERGENCY SOS ALERT* 🚨

*${userName}* needs immediate help!

📍 *Location:* ${location.address}

🗺️ *View on Map:* ${mapLink}

📡 *Live Tracking:* ${liveTrackLink}

⏰ *Time:* ${new Date().toLocaleString()}

⚠️ This is an automated emergency alert from ProtectMe SOS app.

*Please respond immediately or call emergency services!*`

    const smsMessage = `EMERGENCY SOS! ${userName} needs help!\n\nLocation: ${location.address}\nMap: ${mapLink}\n\nPlease respond immediately!`

    if (!navigator.onLine) {
      await sendOfflineSOSToAll(location)
      return {
        sent: sosContacts,
        failed: [],
        sessionId: crypto.randomUUID(),
      }
    }

    // Send alerts to each contact
    for (const contact of sosContacts) {
      try {
        const phoneClean = contact.phone.replace(/[^0-9]/g, "")
        const whatsappUrl = `https://wa.me/${phoneClean}?text=${encodeURIComponent(message)}`

        await supabase.from("sos_alert_recipients").insert({
          alert_id: sessionId,
          contact_id: contact.id,
          notification_method: "sms",
          delivered: true,
        })

        // Send SMS/WhatsApp
        sendOfflineSMS(contact.phone, smsMessage)

        if (sent.length < 3) {
          window.open(whatsappUrl, "_blank")
        }

        sent.push(contact)
      } catch (error) {
        failed.push(contact)
      }
    }

    setCurrentSOSSession({
      sessionId,
      isActive: true,
      startTime: new Date(),
      contacts: sent,
    })

    if ("Notification" in window && Notification.permission === "granted") {
      new Notification("SOS Alert Sent!", {
        body: `Emergency alerts sent to ${sent.length} contacts with your live location.`,
        icon: "/icon-192.jpg",
        tag: "sos-alert",
      })
    }

    return { sent, failed, sessionId }
  }

  const updateSOSLocation = async (sessionId: string, location: { lat: number; lng: number; address: string }) => {
    try {
      await fetch("/api/sos-alert", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "update",
          sessionId,
          location,
        }),
      })

      // Update stored alerts with new location
      const alerts = JSON.parse(localStorage.getItem("protectme_sos_alerts") || "[]")
      const updatedAlerts = alerts.map((alert: any) =>
        alert.sessionId === sessionId ? { ...alert, location, lastUpdate: new Date().toISOString() } : alert,
      )
      localStorage.setItem("protectme_sos_alerts", JSON.stringify(updatedAlerts))
    } catch (error) {
      console.error("Failed to update SOS location:", error)
    }
  }

  const endSOSSession = async (sessionId: string) => {
    if (!user) return

    await supabase
      .from("sos_alerts")
      .update({ status: "resolved", resolved_at: new Date().toISOString() })
      .eq("id", sessionId)

    setCurrentSOSSession(null)

    // Notify contacts that user is safe
    const sosContacts = contacts.filter((c) => c.notifyOnSOS)
    const safeMessage = `✅ *ALL CLEAR* ✅\n\nThe emergency has been resolved. User is now safe.\n\nThank you for your concern!`

    for (const contact of sosContacts.slice(0, 3)) {
      sendOfflineSMS(contact.phone, "ALL CLEAR - Emergency resolved. User is now safe. Thank you!")
    }

    for (const contact of sosContacts.slice(0, 2)) {
      const phoneClean = contact.phone.replace(/[^0-9]/g, "")
      const whatsappUrl = `https://wa.me/${phoneClean}?text=${encodeURIComponent(safeMessage)}`
      window.open(whatsappUrl, "_blank")
    }
  }

  return (
    <ContactsContext.Provider
      value={{
        contacts,
        addContact,
        updateContact,
        deleteContact,
        setPrimaryContact,
        importFromPhone,
        addNearbyPoliceStations,
        sendSOSAlerts,
        updateSOSLocation,
        endSOSSession,
        currentSOSSession,
        sendOfflineSOSToAll,
      }}
    >
      {children}
    </ContactsContext.Provider>
  )
}

export function useContacts() {
  const context = useContext(ContactsContext)
  if (context === undefined) {
    throw new Error("useContacts must be used within a ContactsProvider")
  }
  return context
}
