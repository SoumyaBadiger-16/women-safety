"use client"

import type React from "react"
import { createContext, useContext, useState, useCallback, useRef } from "react"

type VoiceType = "normal" | "police" | "male-adult" | "deep-rough"

interface VoiceMaskContextType {
  isVoiceMaskActive: boolean
  currentVoiceType: VoiceType
  startVoiceMask: (voiceType: VoiceType) => Promise<void>
  stopVoiceMask: () => void
  changeVoiceType: (voiceType: VoiceType) => void
  isSpeaking: boolean
}

const VoiceMaskContext = createContext<VoiceMaskContextType | undefined>(undefined)

export function VoiceMaskProvider({ children }: { children: React.ReactNode }) {
  const [isVoiceMaskActive, setIsVoiceMaskActive] = useState(false)
  const [currentVoiceType, setCurrentVoiceType] = useState<VoiceType>("normal")
  const [isSpeaking, setIsSpeaking] = useState(false)

  const audioContextRef = useRef<AudioContext | null>(null)
  const sourceRef = useRef<MediaStreamAudioSourceNode | null>(null)
  const streamRef = useRef<MediaStream | null>(null)
  const gainNodeRef = useRef<GainNode | null>(null)
  const filterNodeRef = useRef<BiquadFilterNode | null>(null)
  const destinationRef = useRef<MediaStreamAudioDestinationNode | null>(null)

  const startVoiceMask = useCallback(
    async (voiceType: VoiceType) => {
      try {
        // Get microphone access
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
        streamRef.current = stream

        // Create audio context
        audioContextRef.current = new AudioContext()
        const audioContext = audioContextRef.current

        // Create source from microphone
        sourceRef.current = audioContext.createMediaStreamSource(stream)
        const source = sourceRef.current

        // Create gain node for volume control
        gainNodeRef.current = audioContext.createGain()
        const gainNode = gainNodeRef.current

        // Create filter for voice modification
        filterNodeRef.current = audioContext.createBiquadFilter()
        const filterNode = filterNodeRef.current

        // Create destination for modified audio
        destinationRef.current = audioContext.createMediaStreamDestination()
        const destination = destinationRef.current

        // Apply voice modifications based on type
        switch (voiceType) {
          case "police":
            // Police voice: authoritative, slightly deeper
            gainNode.gain.value = 1.5
            filterNode.type = "lowpass"
            filterNode.frequency.value = 2000
            filterNode.Q.value = 1
            break

          case "male-adult":
            // Male adult: deeper voice
            gainNode.gain.value = 1.8
            filterNode.type = "lowshelf"
            filterNode.frequency.value = 200
            filterNode.gain.value = 6
            break

          case "deep-rough":
            // Deep rough voice: very low and intimidating
            gainNode.gain.value = 2.0
            filterNode.type = "lowshelf"
            filterNode.frequency.value = 150
            filterNode.gain.value = 12
            break

          default:
            // Normal voice
            gainNode.gain.value = 1.0
            filterNode.type = "allpass"
            break
        }

        // Connect audio nodes
        source.connect(gainNode)
        gainNode.connect(filterNode)
        filterNode.connect(destination)

        // Monitor audio level to detect speaking
        const analyser = audioContext.createAnalyser()
        gainNode.connect(analyser)
        analyser.fftSize = 256

        const dataArray = new Uint8Array(analyser.frequencyBinCount)

        const checkAudioLevel = () => {
          if (!isVoiceMaskActive) return

          analyser.getByteFrequencyData(dataArray)
          const average = dataArray.reduce((a, b) => a + b) / dataArray.length

          setIsSpeaking(average > 30)

          requestAnimationFrame(checkAudioLevel)
        }

        checkAudioLevel()

        setIsVoiceMaskActive(true)
        setCurrentVoiceType(voiceType)

        console.log("[v0] Voice mask activated with type:", voiceType)
      } catch (error) {
        console.error("[v0] Failed to start voice mask:", error)
        alert("Could not access microphone for voice masking. Please grant microphone permissions.")
      }
    },
    [isVoiceMaskActive],
  )

  const stopVoiceMask = useCallback(() => {
    if (audioContextRef.current) {
      audioContextRef.current.close()
      audioContextRef.current = null
    }

    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop())
      streamRef.current = null
    }

    sourceRef.current = null
    gainNodeRef.current = null
    filterNodeRef.current = null
    destinationRef.current = null

    setIsVoiceMaskActive(false)
    setIsSpeaking(false)
    setCurrentVoiceType("normal")

    console.log("[v0] Voice mask deactivated")
  }, [])

  const changeVoiceType = useCallback(
    (voiceType: VoiceType) => {
      if (isVoiceMaskActive) {
        stopVoiceMask()
        setTimeout(() => startVoiceMask(voiceType), 100)
      } else {
        setCurrentVoiceType(voiceType)
      }
    },
    [isVoiceMaskActive, stopVoiceMask, startVoiceMask],
  )

  return (
    <VoiceMaskContext.Provider
      value={{
        isVoiceMaskActive,
        currentVoiceType,
        startVoiceMask,
        stopVoiceMask,
        changeVoiceType,
        isSpeaking,
      }}
    >
      {children}
    </VoiceMaskContext.Provider>
  )
}

export function useVoiceMask() {
  const context = useContext(VoiceMaskContext)
  if (!context) {
    throw new Error("useVoiceMask must be used within a VoiceMaskProvider")
  }
  return context
}
