-- Core Users and Profiles
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone_number text,
  emergency_phone text,
  blood_group text,
  medical_conditions text,
  allergies text,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

alter table public.profiles enable row level security;

create policy "profiles_select_own" on public.profiles for select using (auth.uid() = id);
create policy "profiles_insert_own" on public.profiles for insert with check (auth.uid() = id);
create policy "profiles_update_own" on public.profiles for update using (auth.uid() = id);

-- Emergency Contacts
create table if not exists public.emergency_contacts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  phone text not null,
  email text,
  relationship text,
  notify_on_sos boolean default true,
  notify_on_check_in boolean default false,
  is_primary boolean default false,
  created_at timestamp with time zone default now()
);

alter table public.emergency_contacts enable row level security;

create policy "contacts_select_own" on public.emergency_contacts for select using (auth.uid() = user_id);
create policy "contacts_insert_own" on public.emergency_contacts for insert with check (auth.uid() = user_id);
create policy "contacts_update_own" on public.emergency_contacts for update using (auth.uid() = user_id);
create policy "contacts_delete_own" on public.emergency_contacts for delete using (auth.uid() = user_id);

-- SOS Alerts
create table if not exists public.sos_alerts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  trigger_type text not null, -- 'manual', 'voice', 'shake', 'gesture', 'button'
  latitude numeric,
  longitude numeric,
  location_address text,
  audio_url text,
  video_url text,
  photo_urls text[],
  status text default 'active', -- 'active', 'cancelled', 'resolved'
  created_at timestamp with time zone default now(),
  resolved_at timestamp with time zone
);

alter table public.sos_alerts enable row level security;

create policy "alerts_select_own" on public.sos_alerts for select using (auth.uid() = user_id);
create policy "alerts_insert_own" on public.sos_alerts for insert with check (auth.uid() = user_id);
create policy "alerts_update_own" on public.sos_alerts for update using (auth.uid() = user_id);

-- SOS Alert Recipients (tracks who was notified)
create table if not exists public.sos_alert_recipients (
  id uuid primary key default gen_random_uuid(),
  alert_id uuid not null references public.sos_alerts(id) on delete cascade,
  contact_id uuid not null references public.emergency_contacts(id) on delete cascade,
  notification_method text, -- 'sms', 'call', 'email'
  sent_at timestamp with time zone default now(),
  delivered boolean default false
);

alter table public.sos_alert_recipients enable row level security;

create policy "recipients_select_by_alert" on public.sos_alert_recipients 
  for select using (
    exists (
      select 1 from public.sos_alerts 
      where sos_alerts.id = alert_id and sos_alerts.user_id = auth.uid()
    )
  );

-- Safety Check-ins
create table if not exists public.safety_checkins (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  scheduled_time timestamp with time zone not null,
  check_in_time timestamp with time zone,
  latitude numeric,
  longitude numeric,
  location_address text,
  status text default 'pending', -- 'pending', 'completed', 'missed', 'triggered_sos'
  notes text,
  created_at timestamp with time zone default now()
);

alter table public.safety_checkins enable row level security;

create policy "checkins_select_own" on public.safety_checkins for select using (auth.uid() = user_id);
create policy "checkins_insert_own" on public.safety_checkins for insert with check (auth.uid() = user_id);
create policy "checkins_update_own" on public.safety_checkins for update using (auth.uid() = user_id);
create policy "checkins_delete_own" on public.safety_checkins for delete using (auth.uid() = user_id);

-- Safe Zones
create table if not exists public.safe_zones (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  latitude numeric not null,
  longitude numeric not null,
  radius numeric default 100, -- in meters
  notify_on_exit boolean default true,
  is_active boolean default true,
  created_at timestamp with time zone default now()
);

alter table public.safe_zones enable row level security;

create policy "safezones_select_own" on public.safe_zones for select using (auth.uid() = user_id);
create policy "safezones_insert_own" on public.safe_zones for insert with check (auth.uid() = user_id);
create policy "safezones_update_own" on public.safe_zones for update using (auth.uid() = user_id);
create policy "safezones_delete_own" on public.safe_zones for delete using (auth.uid() = user_id);

-- Location History
create table if not exists public.location_history (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  latitude numeric not null,
  longitude numeric not null,
  accuracy numeric,
  recorded_at timestamp with time zone default now()
);

alter table public.location_history enable row level security;

create policy "location_select_own" on public.location_history for select using (auth.uid() = user_id);
create policy "location_insert_own" on public.location_history for insert with check (auth.uid() = user_id);

-- Create indexes for performance
create index if not exists idx_sos_alerts_user_id on public.sos_alerts(user_id);
create index if not exists idx_sos_alerts_created_at on public.sos_alerts(created_at desc);
create index if not exists idx_emergency_contacts_user_id on public.emergency_contacts(user_id);
create index if not exists idx_safety_checkins_user_id on public.safety_checkins(user_id);
create index if not exists idx_location_history_user_id on public.location_history(user_id);
create index if not exists idx_location_history_recorded_at on public.location_history(recorded_at desc);
