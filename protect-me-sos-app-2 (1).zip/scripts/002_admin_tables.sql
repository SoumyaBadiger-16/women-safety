-- Admin Users (for admin panel access)
create table if not exists public.admin_users (
  id uuid primary key references auth.users(id) on delete cascade,
  role text default 'admin', -- 'admin', 'super_admin', 'support'
  permissions jsonb default '[]'::jsonb,
  created_at timestamp with time zone default now()
);

alter table public.admin_users enable row level security;

-- Only admins can see admin table
create policy "admins_select_self" on public.admin_users 
  for select using (auth.uid() = id);

-- Admin view of all alerts (for emergency response)
create policy "admins_view_all_alerts" on public.sos_alerts
  for select using (
    exists (
      select 1 from public.admin_users 
      where admin_users.id = auth.uid()
    )
  );

-- Admin view of all users
create policy "admins_view_all_profiles" on public.profiles
  for select using (
    exists (
      select 1 from public.admin_users 
      where admin_users.id = auth.uid()
    )
  );
