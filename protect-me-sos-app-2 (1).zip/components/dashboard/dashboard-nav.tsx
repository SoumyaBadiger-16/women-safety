"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Shield,
  Home,
  Users,
  MapPin,
  FolderLock,
  Settings,
  LogOut,
  User,
  Menu,
  X,
  Navigation,
  Eye,
  Dumbbell,
  Footprints,
  Hand,
  Mic,
  Battery,
  Brain,
  EyeOff,
  PhoneCall,
  Clock,
} from "lucide-react"
import { useState } from "react"
import { cn } from "@/lib/utils"

const navItems = [
  { href: "/dashboard", label: "Dashboard", icon: Home },
  { href: "/dashboard/contacts", label: "Contacts", icon: Users },
  { href: "/dashboard/air-draw-sos", label: "AirDraw SOS", icon: Hand },
  { href: "/dashboard/voice-mask", label: "Voice Mask", icon: Mic },
  { href: "/dashboard/survivor-mode", label: "Survivor Mode", icon: Battery },
  { href: "/dashboard/threat-sense", label: "ThreatSense", icon: Brain },
  { href: "/dashboard/disguise-mode", label: "Disguise Mode", icon: EyeOff },
  { href: "/dashboard/fake-call", label: "Fake Call", icon: PhoneCall },
  { href: "/dashboard/check-in", label: "Safety Check-in", icon: Clock },
  { href: "/dashboard/map", label: "Live Map", icon: MapPin },
  { href: "/dashboard/safe-walk", label: "Safe Navigator", icon: Navigation },
  { href: "/dashboard/threat-scanner", label: "Threat Scanner", icon: Eye },
  { href: "/dashboard/walk-with-me", label: "Walk With Me", icon: Footprints },
  { href: "/dashboard/self-defense", label: "Self Defense", icon: Dumbbell },
  { href: "/dashboard/vault", label: "Evidence Vault", icon: FolderLock },
]

export function DashboardNav() {
  const pathname = usePathname()
  const { user, logout } = useAuth()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-md border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Link href="/dashboard" className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emergency flex items-center justify-center">
              <Shield className="w-5 h-5 text-emergency-foreground" />
            </div>
            <span className="font-semibold text-lg text-foreground hidden sm:inline">ProtectMe</span>
          </Link>

          <div className="hidden md:flex items-center gap-1 overflow-x-auto max-w-2xl">
            {navItems.map((item) => {
              const isActive = pathname === item.href
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors whitespace-nowrap",
                    isActive
                      ? "bg-secondary text-foreground"
                      : "text-muted-foreground hover:text-foreground hover:bg-secondary/50",
                  )}
                >
                  <item.icon className="w-4 h-4" />
                  {item.label}
                </Link>
              )
            })}
          </div>

          <div className="flex items-center gap-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="flex items-center gap-2 text-foreground">
                  <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center">
                    <User className="w-4 h-4" />
                  </div>
                  <span className="hidden sm:inline text-sm">{user?.name || "User"}</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48 bg-card border-border">
                <DropdownMenuItem asChild>
                  <Link href="/dashboard/settings" className="flex items-center gap-2 cursor-pointer">
                    <Settings className="w-4 h-4" />
                    Settings
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator className="bg-border" />
                <DropdownMenuItem
                  onClick={logout}
                  className="flex items-center gap-2 cursor-pointer text-destructive focus:text-destructive"
                >
                  <LogOut className="w-4 h-4" />
                  Sign out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <button className="md:hidden text-foreground p-2" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {mobileMenuOpen && (
        <div className="md:hidden bg-background border-b border-border">
          <div className="px-4 py-4 space-y-2">
            {navItems.map((item) => {
              const isActive = pathname === item.href
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className={cn(
                    "flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors",
                    isActive
                      ? "bg-secondary text-foreground"
                      : "text-muted-foreground hover:text-foreground hover:bg-secondary/50",
                  )}
                >
                  <item.icon className="w-5 h-5" />
                  {item.label}
                </Link>
              )
            })}
          </div>
        </div>
      )}
    </nav>
  )
}
