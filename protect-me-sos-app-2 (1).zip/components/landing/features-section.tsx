import { Shield, MapPin, Video, Users, Bell, Lock, Hand, Mic, Battery, Brain, EyeOff, PhoneCall } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

const features = [
  {
    icon: Shield,
    title: "One-Tap SOS",
    description: "Instantly trigger emergency mode with a single tap. Bypass all menus for immediate help.",
  },
  {
    icon: Hand,
    title: "AirDraw SOS",
    description: "Draw shapes in the air near your phone camera to trigger SOS without touching your device.",
  },
  {
    icon: Mic,
    title: "Voice Mask",
    description: "Change your voice to sound like police or an adult male to deter attackers during calls.",
  },
  {
    icon: Battery,
    title: "Survivor Mode",
    description: "Works even at 1% battery with ultra-low power GPS and SMS location updates every 2 minutes.",
  },
  {
    icon: Brain,
    title: "ThreatSense AI",
    description: "AI predicts danger before it happens by analyzing walking patterns and route deviations.",
  },
  {
    icon: EyeOff,
    title: "Smart Disguise",
    description: "Phone looks switched off but secretly records video, tracks location, and listens for keywords.",
  },
  {
    icon: Video,
    title: "Auto Recording",
    description: "Automatically capture video, audio, and photos as evidence. Stored securely in the cloud.",
  },
  {
    icon: MapPin,
    title: "Live Location",
    description: "Share your real-time GPS location with trusted contacts and emergency services.",
  },
  {
    icon: Users,
    title: "Trusted Contacts",
    description: "Designate emergency contacts who receive instant alerts with your location and status.",
  },
  {
    icon: PhoneCall,
    title: "Fake Call Escape",
    description: "Receive a realistic fake call to create an excuse to leave dangerous situations safely.",
  },
  {
    icon: Bell,
    title: "AI Detection",
    description: "Smart audio analysis detects screams or distress and auto-triggers alerts if you can't.",
  },
  {
    icon: Lock,
    title: "Encrypted Vault",
    description: "All evidence is encrypted and stored securely. Only you can access it with biometric unlock.",
  },
]

export function FeaturesSection() {
  return (
    <section id="features" className="py-24 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-4 mb-16">
          <p className="text-emergency font-medium">Features</p>
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground text-balance">
            Revolutionary Safety Technology
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg leading-relaxed">
            ProtectMe combines cutting-edge AI, gesture recognition, and ultra-low power modes to keep you safe in any
            situation, even when you can't reach your phone.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <Card key={index} className="bg-card border-border hover:border-emergency/50 transition-colors group">
              <CardContent className="p-6 space-y-4">
                <div className="w-12 h-12 rounded-xl bg-secondary flex items-center justify-center group-hover:bg-emergency/10 transition-colors">
                  <feature.icon className="w-6 h-6 text-foreground group-hover:text-emergency transition-colors" />
                </div>
                <h3 className="text-lg font-semibold text-foreground">{feature.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
