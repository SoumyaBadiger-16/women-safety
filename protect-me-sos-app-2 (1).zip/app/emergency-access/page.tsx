"use client"

import { Shield, Hand, Mic, Battery, EyeOff, PhoneCall, Navigation } from "lucide-react"
import Link from "next/link"
import { Card } from "@/components/ui/card"
import { useEffect, useState } from "react"

const quickAccessFeatures = [
  {
    href: "/dashboard/air-draw-sos",
    label: "AirDraw SOS",
    icon: Hand,
    description: "Trigger SOS with hand gestures",
    color: "bg-red-500",
  },
  {
    href: "/dashboard/voice-mask",
    label: "Voice Mask",
    icon: Mic,
    description: "Change your voice for safety",
    color: "bg-blue-500",
  },
  {
    href: "/dashboard/survivor-mode",
    label: "Survivor Mode",
    icon: Battery,
    description: "Ultra low battery mode",
    color: "bg-green-500",
  },
  {
    href: "/dashboard/disguise-mode",
    label: "Disguise Mode",
    icon: EyeOff,
    description: "Phone looks switched off",
    color: "bg-purple-500",
  },
  {
    href: "/dashboard/fake-call",
    label: "Fake Call",
    icon: PhoneCall,
    description: "Receive a fake call",
    color: "bg-orange-500",
  },
  {
    href: "/dashboard/safe-walk",
    label: "Safe Navigator",
    icon: Navigation,
    description: "Navigate safely",
    color: "bg-teal-500",
  },
]

export default function EmergencyAccessPage() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <Shield className="w-12 h-12 text-emergency mx-auto animate-pulse" />
          <p className="mt-4 text-muted-foreground">Loading emergency access...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-red-950/5 to-background">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-emergency mb-4">
            <Shield className="w-8 h-8 text-emergency-foreground" />
          </div>
          <h1 className="text-3xl font-bold text-foreground mb-2">Emergency Access</h1>
          <p className="text-muted-foreground">Quick access to safety features without login</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {quickAccessFeatures.map((feature) => (
            <Link key={feature.href} href={feature.href}>
              <Card className="p-6 hover:shadow-lg transition-all hover:scale-105 cursor-pointer border-2 border-border bg-card h-full">
                <div className={`w-12 h-12 rounded-full ${feature.color} flex items-center justify-center mb-3`}>
                  <feature.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-semibold text-foreground mb-1 text-balance">{feature.label}</h3>
                <p className="text-xs text-muted-foreground text-pretty">{feature.description}</p>
              </Card>
            </Link>
          ))}
        </div>

        <div className="mt-8 text-center">
          <Link
            href="/login"
            className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            Already have an account? Sign in
          </Link>
        </div>

        <div className="mt-6 p-4 rounded-lg bg-secondary/50 border border-border">
          <p className="text-sm text-muted-foreground text-center text-balance">
            <strong className="text-foreground">Note:</strong> This emergency access page allows you to use critical
            safety features without logging in. For full functionality, please create an account.
          </p>
        </div>
      </div>
    </div>
  )
}
