"use client"

import { DashboardLayout } from "@/components/dashboard/dashboard-layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useSurvivorMode } from "@/lib/survivor-mode-context"
import { Battery, BatteryLow, MapPin, MessageSquare, Clock, Shield, AlertTriangle } from "lucide-react"

export default function SurvivorModePage() {
  const { isSurvivorModeActive, batteryLevel, activateSurvivorMode, deactivateSurvivorMode, survivorStats } =
    useSurvivorMode()

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600)
    const minutes = Math.floor((seconds % 3600) / 60)
    const secs = seconds % 60
    return `${hours}h ${minutes}m ${secs}s`
  }

  const getBatteryColor = () => {
    if (batteryLevel <= 5) return "text-emergency"
    if (batteryLevel <= 20) return "text-warning"
    return "text-success"
  }

  const getBatteryIcon = () => {
    return batteryLevel <= 20 ? BatteryLow : Battery
  }

  const BatteryIcon = getBatteryIcon()

  return (
    <DashboardLayout>
      <div className="space-y-6 pb-16">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Survivor Mode</h1>
          <p className="text-sm text-muted-foreground">Ultra-low battery emergency mode</p>
        </div>

        {/* Battery Status */}
        <Card className={`border-2 ${batteryLevel <= 20 ? "border-emergency bg-emergency/5" : "border-border"}`}>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div
                  className={`rounded-full p-3 ${batteryLevel <= 20 ? "bg-emergency/20" : "bg-success/20 animate-pulse"}`}
                >
                  <BatteryIcon className={`h-6 w-6 ${getBatteryColor()}`} />
                </div>
                <div>
                  <p className="text-2xl font-bold">{batteryLevel}%</p>
                  <p className="text-sm text-muted-foreground">Current Battery</p>
                </div>
              </div>
              {batteryLevel <= 20 && (
                <div className="text-right">
                  <div className="flex items-center gap-2 text-emergency">
                    <AlertTriangle className="h-5 w-5" />
                    <span className="font-medium">Low Battery</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">Consider activating Survivor Mode</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Survivor Mode Status */}
        <Card className={`border-2 ${isSurvivorModeActive ? "border-emergency bg-emergency/5" : "border-border"}`}>
          <CardContent className="pt-6">
            <div className="flex items-start gap-4">
              {isSurvivorModeActive ? (
                <div className="rounded-full bg-emergency/20 p-3">
                  <Shield className="h-6 w-6 text-emergency animate-pulse" />
                </div>
              ) : (
                <div className="rounded-full bg-muted p-3">
                  <Shield className="h-6 w-6 text-muted-foreground" />
                </div>
              )}
              <div className="flex-1">
                <CardTitle>Survivor Mode Status</CardTitle>
                <CardDescription className="mt-1">
                  {isSurvivorModeActive
                    ? "Active - All non-essential features disabled. Location tracking via SMS."
                    : "Inactive - Will auto-activate when battery reaches 5%"}
                </CardDescription>

                {isSurvivorModeActive && (
                  <div className="mt-4 grid grid-cols-2 gap-4 text-sm">
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <p className="text-xs text-muted-foreground">Active Time</p>
                        <p className="font-medium">{formatTime(survivorStats.timeActive)}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Battery className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <p className="text-xs text-muted-foreground">Battery at Start</p>
                        <p className="font-medium">{survivorStats.batteryAtStart}%</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <p className="text-xs text-muted-foreground">Location Updates</p>
                        <p className="font-medium">{survivorStats.locationUpdatesSent}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <MessageSquare className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <p className="text-xs text-muted-foreground">SMS Sent</p>
                        <p className="font-medium">{survivorStats.smsMessagesSent}</p>
                      </div>
                    </div>
                  </div>
                )}

                <div className="mt-4">
                  {!isSurvivorModeActive ? (
                    <Button onClick={activateSurvivorMode} className="w-full bg-emergency hover:bg-emergency/90">
                      <Shield className="mr-2 h-4 w-4" />
                      Activate Survivor Mode
                    </Button>
                  ) : (
                    <Button onClick={deactivateSurvivorMode} className="w-full bg-transparent" variant="outline">
                      <Shield className="mr-2 h-4 w-4" />
                      Deactivate Survivor Mode
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* What Gets Disabled */}
        <Card>
          <CardHeader>
            <CardTitle>What Survivor Mode Does</CardTitle>
            <CardDescription>Ultra-low power optimizations for maximum survival time</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-start gap-3 p-3 rounded-lg bg-emergency/5 border border-emergency/20">
              <Battery className="h-5 w-5 text-emergency flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-medium text-emergency">Disables Heavy Apps</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  All non-essential features turned off to save battery
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-3 rounded-lg bg-success/5 border border-success/20">
              <MapPin className="h-5 w-5 text-success flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-medium text-success">Ultra-Low Power GPS</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Low accuracy location tracking to minimize battery drain
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-3 rounded-lg bg-success/5 border border-success/20">
              <MessageSquare className="h-5 w-5 text-success flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-medium text-success">SMS Location Updates</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Sends your location via SMS every 2 minutes to emergency contacts
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-3 rounded-lg bg-muted/50 border border-border">
              <Shield className="h-5 w-5 text-muted-foreground flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-medium">Screen Dimming</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Reduces screen brightness to minimum to extend battery life
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* How It Works */}
        <Card>
          <CardHeader>
            <CardTitle>How Survivor Mode Works</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-3">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-semibold">
                1
              </div>
              <div>
                <h3 className="font-medium">Auto-Activation at 5%</h3>
                <p className="text-sm text-muted-foreground">
                  When battery drops to 5%, Survivor Mode automatically activates to extend phone life
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-semibold">
                2
              </div>
              <div>
                <h3 className="font-medium">Minimal Power Usage</h3>
                <p className="text-sm text-muted-foreground">
                  All heavy features disabled, screen dimmed, only essential tracking continues
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-semibold">
                3
              </div>
              <div>
                <h3 className="font-medium">SMS Location Updates</h3>
                <p className="text-sm text-muted-foreground">
                  Your location is sent via SMS every 2 minutes to all emergency contacts
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-semibold">
                4
              </div>
              <div>
                <h3 className="font-medium">Last Drop Survival</h3>
                <p className="text-sm text-muted-foreground">
                  Your phone survives till the absolute last drop of battery, maximizing rescue time
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
