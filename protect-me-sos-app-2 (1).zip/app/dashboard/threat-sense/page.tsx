"use client"

import { DashboardLayout } from "@/components/dashboard/dashboard-layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useThreatSense } from "@/lib/threat-sense-context"
import { Brain, Shield, ShieldAlert, ShieldCheck, AlertTriangle, Activity, Clock } from "lucide-react"

export default function ThreatSensePage() {
  const { isThreatSenseActive, startThreatSense, stopThreatSense, currentThreatLevel, recentThreats } = useThreatSense()

  const getThreatLevelColor = () => {
    switch (currentThreatLevel) {
      case "danger":
        return "text-emergency"
      case "caution":
        return "text-warning"
      default:
        return "text-success"
    }
  }

  const getThreatLevelIcon = () => {
    switch (currentThreatLevel) {
      case "danger":
        return ShieldAlert
      case "caution":
        return Shield
      default:
        return ShieldCheck
    }
  }

  const getThreatLevelBg = () => {
    switch (currentThreatLevel) {
      case "danger":
        return "bg-emergency/20"
      case "caution":
        return "bg-warning/20"
      default:
        return "bg-success/20"
    }
  }

  const ThreatIcon = getThreatLevelIcon()

  const getSeverityBadge = (severity: "low" | "medium" | "high") => {
    switch (severity) {
      case "high":
        return <Badge className="bg-emergency text-emergency-foreground">High</Badge>
      case "medium":
        return <Badge className="bg-warning text-warning-foreground">Medium</Badge>
      default:
        return <Badge className="bg-muted text-muted-foreground">Low</Badge>
    }
  }

  return (
    <DashboardLayout>
      <div className="space-y-6 pb-16">
        <div>
          <h1 className="text-2xl font-bold text-foreground">ThreatSense Aura</h1>
          <p className="text-sm text-muted-foreground">AI-powered danger prediction before emergencies happen</p>
        </div>

        {/* Threat Level Status */}
        <Card
          className={`border-2 ${
            currentThreatLevel === "danger"
              ? "border-emergency bg-emergency/5"
              : currentThreatLevel === "caution"
                ? "border-warning bg-warning/5"
                : "border-border"
          }`}
        >
          <CardContent className="pt-6">
            <div className="flex items-start gap-4">
              <div className={`rounded-full ${getThreatLevelBg()} p-3`}>
                <ThreatIcon
                  className={`h-6 w-6 ${getThreatLevelColor()} ${isThreatSenseActive ? "animate-pulse" : ""}`}
                />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <CardTitle>Current Threat Level</CardTitle>
                  <Badge className={`capitalize ${getThreatLevelColor()} bg-transparent border`}>
                    {currentThreatLevel}
                  </Badge>
                </div>
                <CardDescription className="mt-1">
                  {isThreatSenseActive
                    ? currentThreatLevel === "danger"
                      ? "High-risk patterns detected - consider taking action"
                      : currentThreatLevel === "caution"
                        ? "Some unusual patterns detected - stay alert"
                        : "No threats detected - you're safe"
                    : "Start monitoring to enable AI-powered threat detection"}
                </CardDescription>

                {isThreatSenseActive && (
                  <div className="mt-4 flex items-center gap-2 text-sm">
                    <Activity className={`h-4 w-4 ${getThreatLevelColor()} animate-pulse`} />
                    <span className="text-muted-foreground">AI actively monitoring your environment</span>
                  </div>
                )}

                <div className="mt-4">
                  {!isThreatSenseActive ? (
                    <Button onClick={startThreatSense} className="w-full bg-success hover:bg-success/90">
                      <Brain className="mr-2 h-4 w-4" />
                      Start ThreatSense AI
                    </Button>
                  ) : (
                    <Button onClick={stopThreatSense} className="w-full bg-transparent" variant="outline">
                      <Brain className="mr-2 h-4 w-4" />
                      Stop Monitoring
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Recent Threats */}
        {recentThreats.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Recent Threat Detections</CardTitle>
              <CardDescription>AI-detected unusual patterns in your environment</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {recentThreats.map((threat, index) => (
                <div
                  key={index}
                  className={`p-4 rounded-lg border ${
                    threat.severity === "high"
                      ? "border-emergency bg-emergency/5"
                      : threat.severity === "medium"
                        ? "border-warning bg-warning/5"
                        : "border-border bg-muted/30"
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        {getSeverityBadge(threat.severity)}
                        <span className="text-xs text-muted-foreground capitalize">
                          {threat.type.replace("-", " ")}
                        </span>
                      </div>
                      <p className="text-sm font-medium">{threat.message}</p>
                    </div>
                    <div className="flex items-center gap-1 text-xs text-muted-foreground flex-shrink-0">
                      <Clock className="h-3 w-3" />
                      {threat.timestamp.toLocaleTimeString()}
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        {/* What ThreatSense Monitors */}
        <Card>
          <CardHeader>
            <CardTitle>What ThreatSense AI Monitors</CardTitle>
            <CardDescription>Passive signals analyzed for danger prediction</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-start gap-3 p-3 rounded-lg bg-muted/50 border border-border">
              <Activity className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-medium">Behavioral Pattern Deviation</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Tracks your walking speed, routes, and travel timings for unusual changes
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-3 rounded-lg bg-muted/50 border border-border">
              <Shield className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-medium">Location Safety Analysis</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Detects when you enter isolated or unfamiliar areas away from safe zones
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-3 rounded-lg bg-muted/50 border border-border">
              <Clock className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-medium">Unusual Timing Detection</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Alerts you when traveling during late hours or atypical times
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-3 rounded-lg bg-muted/50 border border-border">
              <AlertTriangle className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-medium">Panic Pace Detection</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Identifies sudden fast walking or running that may indicate panic or danger
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* How It Works */}
        <Card>
          <CardHeader>
            <CardTitle>How ThreatSense AI Works</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-3">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-semibold">
                1
              </div>
              <div>
                <h3 className="font-medium">Learn Your Patterns</h3>
                <p className="text-sm text-muted-foreground">
                  AI learns your normal behavior - walking speed, usual routes, and typical travel times
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-semibold">
                2
              </div>
              <div>
                <h3 className="font-medium">Continuous Monitoring</h3>
                <p className="text-sm text-muted-foreground">
                  Passively watches for micro-signals and pattern deviations in the background
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-semibold">
                3
              </div>
              <div>
                <h3 className="font-medium">Predict Danger Early</h3>
                <p className="text-sm text-muted-foreground">
                  Detects unusual patterns BEFORE you realize danger, giving you early warnings
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-semibold">
                4
              </div>
              <div>
                <h3 className="font-medium">Proactive Alerts</h3>
                <p className="text-sm text-muted-foreground">
                  Sends notifications when threat level increases so you can take action before it's too late
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
