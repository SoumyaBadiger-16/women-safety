"use client"

import { DashboardNav } from "@/components/dashboard/dashboard-nav"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { useDisguiseMode } from "@/lib/disguise-mode-context"
import { EyeOff, Video, Mic, MapPin, Flashlight, ShieldAlert, Shield } from "lucide-react"

export default function DisguiseModePage() {
  const {
    isDisguiseActive,
    activateDisguiseMode,
    deactivateDisguiseMode,
    disguiseSettings,
    updateDisguiseSettings,
    disguiseStatus,
  } = useDisguiseMode()

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav />

      <main className="pt-20 pb-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto space-y-6">
          {/* Header */}
          <div className="space-y-2">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-muted">
                <EyeOff className="w-6 h-6 text-foreground" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">Smart Disguise Mode</h1>
                <p className="text-muted-foreground">Phone appears off while staying protected</p>
              </div>
            </div>
          </div>

          {/* Status Card */}
          <Card className={`border-2 ${isDisguiseActive ? "border-emergency bg-emergency/5" : "border-border"}`}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {isDisguiseActive ? (
                    <ShieldAlert className="w-5 h-5 text-emergency" />
                  ) : (
                    <Shield className="w-5 h-5 text-muted-foreground" />
                  )}
                  <CardTitle>Disguise Status</CardTitle>
                </div>
                {isDisguiseActive ? (
                  <Badge variant="destructive" className="animate-pulse">
                    ACTIVE
                  </Badge>
                ) : (
                  <Badge variant="secondary">Inactive</Badge>
                )}
              </div>
              <CardDescription>
                {isDisguiseActive
                  ? "Your phone appears off but is actively protecting you"
                  : "Activate to make your phone appear switched off while recording"}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {isDisguiseActive && (
                <div className="grid grid-cols-2 gap-4 p-4 rounded-lg bg-muted/50">
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">Recording</p>
                    <p className="text-sm font-medium flex items-center gap-2">
                      <div
                        className={`w-2 h-2 rounded-full ${disguiseStatus.isRecording ? "bg-emergency animate-pulse" : "bg-muted-foreground"}`}
                      />
                      {disguiseStatus.isRecording ? "Active" : "Inactive"}
                    </p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">Voice Listening</p>
                    <p className="text-sm font-medium flex items-center gap-2">
                      <div
                        className={`w-2 h-2 rounded-full ${disguiseStatus.isListening ? "bg-emergency animate-pulse" : "bg-muted-foreground"}`}
                      />
                      {disguiseStatus.isListening ? "Active" : "Inactive"}
                    </p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">Location Updates</p>
                    <p className="text-sm font-medium">{disguiseStatus.locationUpdates} sent</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">SOS Flash Blinks</p>
                    <p className="text-sm font-medium">{disguiseStatus.flashBlinks} times</p>
                  </div>
                </div>
              )}

              <div className="flex gap-3">
                {!isDisguiseActive ? (
                  <Button onClick={activateDisguiseMode} className="flex-1 bg-emergency hover:bg-emergency/90">
                    <EyeOff className="w-4 h-4 mr-2" />
                    Activate Disguise Mode
                  </Button>
                ) : (
                  <Button onClick={deactivateDisguiseMode} className="flex-1 bg-transparent" variant="outline">
                    <Shield className="w-4 h-4 mr-2" />
                    Deactivate Disguise Mode
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Settings Card */}
          <Card className="border-border">
            <CardHeader>
              <CardTitle>Disguise Mode Settings</CardTitle>
              <CardDescription>Configure what happens when disguise mode is active</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Camera Setting */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Video className="w-5 h-5 text-muted-foreground" />
                  <div>
                    <Label htmlFor="camera-setting">Camera Recording</Label>
                    <p className="text-xs text-muted-foreground">Record video evidence in background</p>
                  </div>
                </div>
                <Switch
                  id="camera-setting"
                  checked={disguiseSettings.enableCamera}
                  onCheckedChange={(checked) => updateDisguiseSettings({ enableCamera: checked })}
                  disabled={isDisguiseActive}
                />
              </div>

              {/* Microphone Setting */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Mic className="w-5 h-5 text-muted-foreground" />
                  <div>
                    <Label htmlFor="mic-setting">Voice Keyword Listening</Label>
                    <p className="text-xs text-muted-foreground">Listen for rescue keyword</p>
                  </div>
                </div>
                <Switch
                  id="mic-setting"
                  checked={disguiseSettings.enableMicrophone}
                  onCheckedChange={(checked) => updateDisguiseSettings({ enableMicrophone: checked })}
                  disabled={isDisguiseActive}
                />
              </div>

              {/* Voice Keyword Input */}
              {disguiseSettings.enableMicrophone && (
                <div className="pl-8 space-y-2">
                  <Label htmlFor="voice-keyword">Rescue Keyword</Label>
                  <Input
                    id="voice-keyword"
                    value={disguiseSettings.voiceKeyword}
                    onChange={(e) => updateDisguiseSettings({ voiceKeyword: e.target.value })}
                    placeholder="e.g., rescue me"
                    disabled={isDisguiseActive}
                  />
                  <p className="text-xs text-muted-foreground">Say this keyword to trigger SOS</p>
                </div>
              )}

              {/* Location Setting */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <MapPin className="w-5 h-5 text-muted-foreground" />
                  <div>
                    <Label htmlFor="location-setting">Location Tracking</Label>
                    <p className="text-xs text-muted-foreground">Update location every 2 minutes</p>
                  </div>
                </div>
                <Switch
                  id="location-setting"
                  checked={disguiseSettings.enableLocationTracking}
                  onCheckedChange={(checked) => updateDisguiseSettings({ enableLocationTracking: checked })}
                  disabled={isDisguiseActive}
                />
              </div>

              {/* Flashlight Setting */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Flashlight className="w-5 h-5 text-muted-foreground" />
                  <div>
                    <Label htmlFor="flash-setting">SOS Flashlight</Label>
                    <p className="text-xs text-muted-foreground">Blink SOS pattern from back camera</p>
                  </div>
                </div>
                <Switch
                  id="flash-setting"
                  checked={disguiseSettings.enableSOSFlashlight}
                  onCheckedChange={(checked) => updateDisguiseSettings({ enableSOSFlashlight: checked })}
                  disabled={isDisguiseActive}
                />
              </div>
            </CardContent>
          </Card>

          {/* How it Works */}
          <Card className="border-border">
            <CardHeader>
              <CardTitle>How Disguise Mode Works</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex gap-3">
                  <div className="w-8 h-8 rounded-full bg-emergency/10 flex items-center justify-center flex-shrink-0">
                    <span className="text-sm font-semibold text-emergency">1</span>
                  </div>
                  <div>
                    <p className="font-medium">Screen Goes Black</p>
                    <p className="text-sm text-muted-foreground">
                      Phone appears completely switched off with pitch-black screen and zero volume
                    </p>
                  </div>
                </div>
                <div className="flex gap-3">
                  <div className="w-8 h-8 rounded-full bg-emergency/10 flex items-center justify-center flex-shrink-0">
                    <span className="text-sm font-semibold text-emergency">2</span>
                  </div>
                  <div>
                    <p className="font-medium">Background Protection Active</p>
                    <p className="text-sm text-muted-foreground">
                      Camera records, microphone listens for keywords, and location updates every 2 minutes
                    </p>
                  </div>
                </div>
                <div className="flex gap-3">
                  <div className="w-8 h-8 rounded-full bg-emergency/10 flex items-center justify-center flex-shrink-0">
                    <span className="text-sm font-semibold text-emergency">3</span>
                  </div>
                  <div>
                    <p className="font-medium">Silent SOS Signals</p>
                    <p className="text-sm text-muted-foreground">
                      Flashlight blinks SOS in Morse code (· · · − − −· · ·) from back camera
                    </p>
                  </div>
                </div>
                <div className="flex gap-3">
                  <div className="w-8 h-8 rounded-full bg-emergency/10 flex items-center justify-center flex-shrink-0">
                    <span className="text-sm font-semibold text-emergency">4</span>
                  </div>
                  <div>
                    <p className="font-medium">Voice Activation</p>
                    <p className="text-sm text-muted-foreground">
                      Say your rescue keyword to instantly trigger full SOS alert and exit disguise mode
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
