"use client"

import { DashboardLayout } from "@/components/dashboard/dashboard-layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { useGestureDetection } from "@/lib/gesture-detection-context"
import { Hand, Circle, Zap, AlertTriangle, Camera, CheckCircle2 } from "lucide-react"

export default function AirDrawSOSPage() {
  const {
    isGestureDetectionActive,
    startGestureDetection,
    stopGestureDetection,
    gestureSettings,
    updateGestureSettings,
    detectedGestures,
    lastGestureTime,
  } = useGestureDetection()

  return (
    <DashboardLayout>
      <div className="space-y-6 pb-16">
        <div>
          <h1 className="text-2xl font-bold text-foreground">AirDraw SOS</h1>
          <p className="text-sm text-muted-foreground">Trigger SOS with hand gestures in the air</p>
        </div>

        {/* Status Card */}
        <Card className={`border-2 ${isGestureDetectionActive ? "border-emergency bg-emergency/5" : "border-border"}`}>
          <CardContent className="pt-6">
            <div className="flex items-start gap-4">
              {isGestureDetectionActive ? (
                <div className="rounded-full bg-emergency/20 p-3">
                  <Camera className="h-6 w-6 text-emergency animate-pulse" />
                </div>
              ) : (
                <div className="rounded-full bg-muted p-3">
                  <Hand className="h-6 w-6 text-muted-foreground" />
                </div>
              )}
              <div className="flex-1">
                <CardTitle>Gesture Detection Status</CardTitle>
                <CardDescription className="mt-1">
                  {isGestureDetectionActive
                    ? "Camera is watching for air gestures. Draw shapes near your phone."
                    : "Start gesture detection to enable hands-free SOS triggering"}
                </CardDescription>

                {isGestureDetectionActive && (
                  <div className="mt-4 space-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-success animate-pulse" />
                      <span className="text-success-foreground">Camera Active</span>
                    </div>
                    {lastGestureTime && (
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="h-4 w-4 text-success" />
                        <span className="text-muted-foreground">
                          Last gesture: {lastGestureTime.toLocaleTimeString()}
                        </span>
                      </div>
                    )}
                  </div>
                )}

                <div className="mt-4 flex gap-2">
                  {!isGestureDetectionActive ? (
                    <Button onClick={startGestureDetection} className="flex-1 bg-emergency hover:bg-emergency/90">
                      <Camera className="mr-2 h-4 w-4" />
                      Start Detection
                    </Button>
                  ) : (
                    <Button onClick={stopGestureDetection} className="flex-1 bg-transparent" variant="outline">
                      <Camera className="mr-2 h-4 w-4" />
                      Stop Detection
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Gesture Settings */}
        <Card>
          <CardHeader>
            <CardTitle>Gesture Settings</CardTitle>
            <CardDescription>Configure which gestures trigger SOS</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Circle className="h-5 w-5 text-muted-foreground" />
                <div>
                  <Label htmlFor="circle-gesture">Circle Gesture</Label>
                  <p className="text-sm text-muted-foreground">Draw a circle in the air</p>
                </div>
              </div>
              <Switch
                id="circle-gesture"
                checked={gestureSettings.enableCircleGesture}
                onCheckedChange={(checked) => updateGestureSettings({ enableCircleGesture: checked })}
                disabled={isGestureDetectionActive}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Zap className="h-5 w-5 text-muted-foreground" />
                <div>
                  <Label htmlFor="z-gesture">Z Gesture</Label>
                  <p className="text-sm text-muted-foreground">Draw a Z shape in the air</p>
                </div>
              </div>
              <Switch
                id="z-gesture"
                checked={gestureSettings.enableZGesture}
                onCheckedChange={(checked) => updateGestureSettings({ enableZGesture: checked })}
                disabled={isGestureDetectionActive}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <AlertTriangle className="h-5 w-5 text-muted-foreground" />
                <div>
                  <Label htmlFor="sos-gesture">SOS Pattern</Label>
                  <p className="text-sm text-muted-foreground">Quick repeated hand movements</p>
                </div>
              </div>
              <Switch
                id="sos-gesture"
                checked={gestureSettings.enableSOSGesture}
                onCheckedChange={(checked) => updateGestureSettings({ enableSOSGesture: checked })}
                disabled={isGestureDetectionActive}
              />
            </div>

            <div className="space-y-2">
              <Label>Detection Sensitivity</Label>
              <Slider
                value={[gestureSettings.sensitivity * 100]}
                onValueChange={([value]) => updateGestureSettings({ sensitivity: value / 100 })}
                min={50}
                max={100}
                step={10}
                disabled={isGestureDetectionActive}
              />
              <p className="text-xs text-muted-foreground">
                Higher sensitivity detects gestures faster but may have false positives
              </p>
            </div>
          </CardContent>
        </Card>

        {/* How It Works */}
        <Card>
          <CardHeader>
            <CardTitle>How AirDraw SOS Works</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-3">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-semibold">
                1
              </div>
              <div>
                <h3 className="font-medium">Enable Detection</h3>
                <p className="text-sm text-muted-foreground">
                  Start gesture detection to activate your front camera for motion tracking
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-semibold">
                2
              </div>
              <div>
                <h3 className="font-medium">Draw in Air</h3>
                <p className="text-sm text-muted-foreground">
                  Move your hand in front of the camera to draw shapes - circle, Z, or quick movements
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-semibold">
                3
              </div>
              <div>
                <h3 className="font-medium">Automatic SOS</h3>
                <p className="text-sm text-muted-foreground">
                  When gesture is detected, SOS is triggered automatically without touching your phone
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-semibold">
                4
              </div>
              <div>
                <h3 className="font-medium">Works in Background</h3>
                <p className="text-sm text-muted-foreground">
                  Keep detection running even when phone is in dangerous situations
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Recent Gestures */}
        {detectedGestures.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Recent Gestures Detected</CardTitle>
              <CardDescription>Last {detectedGestures.length} gestures that triggered SOS</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {detectedGestures.map((gesture, index) => (
                  <div
                    key={index}
                    className="px-3 py-1 rounded-full bg-emergency/10 text-emergency text-sm font-medium capitalize"
                  >
                    {gesture}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  )
}
