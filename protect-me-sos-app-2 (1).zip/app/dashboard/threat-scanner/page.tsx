"use client"

import { useState, useEffect, useRef, useCallback } from "react"
import { DashboardNav } from "@/components/dashboard/dashboard-nav"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Camera, CameraOff, Volume2, VolumeX, AlertTriangle, Users, Loader2, FlipHorizontal, Info } from "lucide-react"
import { cn } from "@/lib/utils"
import * as cocoSsd from "@tensorflow-models/coco-ssd"
import "@tensorflow/tfjs"

interface Detection {
  id: string
  class: string
  score: number
  bbox: number[]
  threatLevel: "safe" | "caution" | "danger"
  color: string
  distance: number
}

export default function ThreatScannerPage() {
  const [cameraActive, setCameraActive] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [modelLoaded, setModelLoaded] = useState(false)
  const [facingMode, setFacingMode] = useState<"user" | "environment">("environment")
  const [voiceEnabled, setVoiceEnabled] = useState(true)
  const [detections, setDetections] = useState<Detection[]>([])
  const [threatLevel, setThreatLevel] = useState<"safe" | "caution" | "danger">("safe")
  const [personCount, setPersonCount] = useState(0)
  const [lastAlert, setLastAlert] = useState<string>("")
  const [modelError, setModelError] = useState<string | null>(null)
  const [videoReady, setVideoReady] = useState(false)

  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const modelRef = useRef<cocoSsd.ObjectDetection | null>(null)
  const streamRef = useRef<MediaStream | null>(null)
  const animationRef = useRef<number | null>(null)
  const lastAlertTimeRef = useRef<number>(0)
  const isDetectingRef = useRef(false)

  // Load model on mount
  useEffect(() => {
    const loadModel = async () => {
      try {
        setIsLoading(true)
        setModelError(null)
        const model = await cocoSsd.load({ base: "lite_mobilenet_v2" })
        modelRef.current = model
        setModelLoaded(true)
      } catch (error) {
        console.error("Model load error:", error)
        setModelError("Failed to load detection model. Please refresh.")
      } finally {
        setIsLoading(false)
      }
    }
    loadModel()

    return () => {
      isDetectingRef.current = false
      if (animationRef.current) cancelAnimationFrame(animationRef.current)
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop())
      }
    }
  }, [])

  const assessThreat = (
    detectedClass: string,
    score: number,
    personCount: number,
  ): { level: "safe" | "caution" | "danger"; color: string } => {
    if (personCount >= 4) {
      return { level: "danger", color: "#ef4444" }
    }
    if (personCount >= 2) {
      return { level: "caution", color: "#f59e0b" }
    }
    if (detectedClass === "person" && score > 0.7) {
      return { level: "safe", color: "#22c55e" }
    }
    if (["car", "truck", "motorcycle", "bus"].includes(detectedClass)) {
      return { level: "caution", color: "#f59e0b" }
    }
    return { level: "safe", color: "#22c55e" }
  }

  const speakAlert = useCallback(
    (message: string) => {
      if (!voiceEnabled) return
      const now = Date.now()
      if (now - lastAlertTimeRef.current < 5000) return
      if (message === lastAlert) return

      lastAlertTimeRef.current = now
      setLastAlert(message)

      if ("speechSynthesis" in window) {
        window.speechSynthesis.cancel()
        const utterance = new SpeechSynthesisUtterance(message)
        utterance.rate = 1.1
        utterance.pitch = 1
        window.speechSynthesis.speak(utterance)
      }
    },
    [voiceEnabled, lastAlert],
  )

  const detectObjects = useCallback(async () => {
    if (!isDetectingRef.current) {
      return
    }

    if (!modelRef.current || !videoRef.current || !canvasRef.current) {
      animationRef.current = requestAnimationFrame(detectObjects)
      return
    }

    const video = videoRef.current
    const canvas = canvasRef.current
    const ctx = canvas.getContext("2d")

    const isVideoReady =
      video.readyState >= 2 && // HAVE_CURRENT_DATA or higher
      video.videoWidth > 0 &&
      video.videoHeight > 0 &&
      !video.paused &&
      !video.ended

    if (!isVideoReady) {
      // Video not ready yet, wait and try again without running detection
      if (isDetectingRef.current) {
        animationRef.current = requestAnimationFrame(detectObjects)
      }
      return
    }

    // Set canvas size only when video is valid
    if (canvas.width !== video.videoWidth || canvas.height !== video.videoHeight) {
      canvas.width = video.videoWidth
      canvas.height = video.videoHeight
    }

    try {
      const predictions = await modelRef.current.detect(video)

      ctx?.clearRect(0, 0, canvas.width, canvas.height)

      const people = predictions.filter((p) => p.class === "person")
      setPersonCount(people.length)

      const newDetections: Detection[] = []
      let highestThreat: "safe" | "caution" | "danger" = "safe"

      predictions.forEach((pred, idx) => {
        if (pred.score < 0.5) return

        const { level, color } = assessThreat(pred.class, pred.score, people.length)
        const bboxHeight = pred.bbox[3]
        const estimatedDistance = Math.max(1, Math.round((canvas.height / bboxHeight) * 2))

        newDetections.push({
          id: `det-${idx}`,
          class: pred.class,
          score: pred.score,
          bbox: pred.bbox,
          threatLevel: level,
          color,
          distance: estimatedDistance,
        })

        if (level === "danger") highestThreat = "danger"
        else if (level === "caution" && highestThreat !== "danger") highestThreat = "caution"

        if (ctx) {
          ctx.strokeStyle = color
          ctx.lineWidth = 3
          ctx.strokeRect(pred.bbox[0], pred.bbox[1], pred.bbox[2], pred.bbox[3])

          ctx.fillStyle = color
          const label = `${pred.class} ~${estimatedDistance}m`
          const labelWidth = ctx.measureText(label).width + 10
          ctx.fillRect(pred.bbox[0], pred.bbox[1] - 25, labelWidth, 25)

          ctx.fillStyle = "#000"
          ctx.font = "14px sans-serif"
          ctx.fillText(label, pred.bbox[0] + 5, pred.bbox[1] - 7)
        }
      })

      setDetections(newDetections)
      setThreatLevel(highestThreat)

      if (people.length >= 4) {
        speakAlert(`Warning! Group of ${people.length} people detected ahead`)
      } else if (highestThreat === "danger") {
        speakAlert("Caution! Potential threat detected nearby")
      }
    } catch (error: any) {
      if (!error?.message?.includes("texture size")) {
        console.error("Detection error:", error)
      }
    }

    if (isDetectingRef.current) {
      animationRef.current = requestAnimationFrame(detectObjects)
    }
  }, [speakAlert])

  const startCamera = async () => {
    if (!modelLoaded) {
      alert("Please wait for the detection model to load")
      return
    }

    setIsLoading(true)
    setVideoReady(false)

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode,
          width: { ideal: 640 },
          height: { ideal: 480 },
        },
        audio: false,
      })

      streamRef.current = stream

      if (videoRef.current) {
        videoRef.current.srcObject = stream

        await new Promise<void>((resolve, reject) => {
          const video = videoRef.current!
          const timeout = setTimeout(() => reject(new Error("Video load timeout")), 10000)

          const checkReady = () => {
            if (video.readyState >= 2 && video.videoWidth > 0 && video.videoHeight > 0) {
              clearTimeout(timeout)
              resolve()
            }
          }

          video.onloadeddata = checkReady
          video.oncanplay = checkReady
          video.onloadedmetadata = () => {
            video.play().then(checkReady).catch(reject)
          }
        })

        await new Promise((resolve) => setTimeout(resolve, 1000))

        setVideoReady(true)
        setCameraActive(true)

        isDetectingRef.current = true
        animationRef.current = requestAnimationFrame(detectObjects)
      }
    } catch (error: any) {
      console.error("Camera error:", error)
      alert("Camera access denied or timeout. Please allow camera access and try again.")
    } finally {
      setIsLoading(false)
    }
  }

  const stopCamera = () => {
    isDetectingRef.current = false

    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current)
      animationRef.current = null
    }

    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop())
      streamRef.current = null
    }

    if (videoRef.current) {
      videoRef.current.srcObject = null
    }

    setCameraActive(false)
    setVideoReady(false)
    setDetections([])
    setPersonCount(0)
    setThreatLevel("safe")
  }

  const flipCamera = async () => {
    const newMode = facingMode === "environment" ? "user" : "environment"
    setFacingMode(newMode)
    if (cameraActive) {
      stopCamera()
      setTimeout(() => startCamera(), 500)
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav />
      <main className="container max-w-2xl mx-auto px-4 py-6 pb-24">
        <div className="space-y-6">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-foreground">Threat Scanner</h1>
            <p className="text-muted-foreground mt-1">Real-time person detection with threat analysis</p>
          </div>

          <div className="flex items-center justify-between p-3 rounded-lg bg-card border border-border">
            <div className="flex items-center gap-3">
              <div
                className={cn(
                  "w-3 h-3 rounded-full",
                  cameraActive && videoReady ? "bg-green-500 animate-pulse" : "bg-gray-500",
                )}
              />
              <span className="text-sm text-foreground">
                {isLoading
                  ? "Starting..."
                  : cameraActive
                    ? videoReady
                      ? "Scanning Active"
                      : "Initializing..."
                    : "Camera Off"}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <Badge
                className={cn(
                  threatLevel === "safe" && "bg-green-500/20 text-green-500",
                  threatLevel === "caution" && "bg-yellow-500/20 text-yellow-500",
                  threatLevel === "danger" && "bg-red-500/20 text-red-500",
                )}
              >
                {threatLevel.toUpperCase()}
              </Badge>
              <Badge variant="outline">
                <Users className="w-3 h-3 mr-1" />
                {personCount}
              </Badge>
            </div>
          </div>

          {!modelLoaded && !modelError && (
            <div className="p-4 rounded-lg bg-blue-500/10 border border-blue-500/30 flex items-center gap-3">
              <Loader2 className="w-5 h-5 text-blue-500 animate-spin" />
              <span className="text-sm text-blue-400">Loading AI detection model...</span>
            </div>
          )}

          {modelError && (
            <div className="p-4 rounded-lg bg-red-500/10 border border-red-500/30 flex items-center gap-3">
              <AlertTriangle className="w-5 h-5 text-red-500" />
              <span className="text-sm text-red-400">{modelError}</span>
            </div>
          )}

          <div className="relative rounded-xl overflow-hidden bg-black aspect-video">
            <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
            <canvas ref={canvasRef} className="absolute top-0 left-0 w-full h-full" />

            {!cameraActive && (
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-gray-900/90">
                <Camera className="w-16 h-16 text-muted-foreground mb-4" />
                <p className="text-muted-foreground mb-4">Camera is off</p>
                <Button
                  onClick={startCamera}
                  disabled={isLoading || !modelLoaded}
                  className="bg-emergency hover:bg-emergency/90"
                >
                  {isLoading ? <Loader2 className="w-5 h-5 mr-2 animate-spin" /> : <Camera className="w-5 h-5 mr-2" />}
                  Start Camera
                </Button>
              </div>
            )}

            {cameraActive && !videoReady && (
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-gray-900/80">
                <Loader2 className="w-12 h-12 text-emergency animate-spin mb-4" />
                <p className="text-white">Initializing camera...</p>
              </div>
            )}

            {cameraActive && videoReady && threatLevel !== "safe" && (
              <div
                className={cn(
                  "absolute top-4 left-4 right-4 p-3 rounded-lg flex items-center gap-2",
                  threatLevel === "caution" && "bg-yellow-500/90",
                  threatLevel === "danger" && "bg-red-500/90 animate-pulse",
                )}
              >
                <AlertTriangle className="w-5 h-5 text-white" />
                <span className="text-white font-medium">
                  {threatLevel === "danger" ? "Group detected - Stay alert!" : "Exercise caution"}
                </span>
              </div>
            )}
          </div>

          <div className="flex justify-center gap-3">
            {cameraActive ? (
              <Button variant="destructive" onClick={stopCamera}>
                <CameraOff className="w-5 h-5 mr-2" />
                Stop Camera
              </Button>
            ) : (
              <Button
                onClick={startCamera}
                disabled={isLoading || !modelLoaded}
                className="bg-emergency hover:bg-emergency/90"
              >
                <Camera className="w-5 h-5 mr-2" />
                Start Camera
              </Button>
            )}
            <Button variant="outline" onClick={flipCamera} disabled={isLoading} className="bg-transparent">
              <FlipHorizontal className="w-5 h-5" />
            </Button>
            <Button
              variant="outline"
              onClick={() => setVoiceEnabled(!voiceEnabled)}
              className={cn("bg-transparent", voiceEnabled && "border-green-500/50")}
            >
              {voiceEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
            </Button>
          </div>

          <div className="p-4 rounded-lg bg-card border border-border">
            <h3 className="font-medium text-foreground mb-3 flex items-center gap-2">
              <Info className="w-4 h-4" />
              Detection Colors
            </h3>
            <div className="grid grid-cols-3 gap-3 text-sm">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-green-500" />
                <span className="text-muted-foreground">Safe (1 person)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-yellow-500" />
                <span className="text-muted-foreground">Caution (2-3)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-red-500" />
                <span className="text-muted-foreground">Danger (4+)</span>
              </div>
            </div>
          </div>

          {detections.length > 0 && (
            <div className="p-4 rounded-lg bg-card border border-border">
              <h3 className="font-medium text-foreground mb-3">Current Detections</h3>
              <div className="space-y-2">
                {detections.map((det) => (
                  <div key={det.id} className="flex items-center justify-between p-2 rounded bg-secondary/50">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: det.color }} />
                      <span className="text-foreground capitalize">{det.class}</span>
                    </div>
                    <span className="text-sm text-muted-foreground">~{det.distance}m away</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
