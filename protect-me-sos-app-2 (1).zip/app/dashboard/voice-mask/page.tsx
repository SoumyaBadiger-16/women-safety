"use client"

import { DashboardLayout } from "@/components/dashboard/dashboard-layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useVoiceMask } from "@/lib/voice-mask-context"
import { Mic, MicOff, Shield, User, Volume2, AlertCircle } from "lucide-react"

const voiceOptions = [
  {
    id: "police" as const,
    name: "Police Officer",
    description: "Authoritative and commanding voice",
    icon: Shield,
  },
  {
    id: "male-adult" as const,
    name: "Male Adult",
    description: "Deep masculine voice",
    icon: User,
  },
  {
    id: "deep-rough" as const,
    name: "Deep Rough",
    description: "Very intimidating low voice",
    icon: Volume2,
  },
]

export default function VoiceMaskPage() {
  const { isVoiceMaskActive, currentVoiceType, startVoiceMask, stopVoiceMask, changeVoiceType, isSpeaking } =
    useVoiceMask()

  return (
    <DashboardLayout>
      <div className="space-y-6 pb-16">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Voice Mask</h1>
          <p className="text-sm text-muted-foreground">Change your voice to sound stronger in dangerous situations</p>
        </div>

        {/* Status Card */}
        <Card className={`border-2 ${isVoiceMaskActive ? "border-success bg-success/5" : "border-border"}`}>
          <CardContent className="pt-6">
            <div className="flex items-start gap-4">
              {isVoiceMaskActive ? (
                <div className="rounded-full bg-success/20 p-3">
                  <Mic className={`h-6 w-6 text-success ${isSpeaking ? "animate-pulse" : ""}`} />
                </div>
              ) : (
                <div className="rounded-full bg-muted p-3">
                  <MicOff className="h-6 w-6 text-muted-foreground" />
                </div>
              )}
              <div className="flex-1">
                <CardTitle>Voice Mask Status</CardTitle>
                <CardDescription className="mt-1">
                  {isVoiceMaskActive
                    ? `Active - Your voice sounds like: ${voiceOptions.find((v) => v.id === currentVoiceType)?.name}`
                    : "Select a voice type and activate to change how you sound"}
                </CardDescription>

                {isVoiceMaskActive && (
                  <div className="mt-4 space-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      <div className={`w-2 h-2 rounded-full ${isSpeaking ? "bg-success animate-pulse" : "bg-muted"}`} />
                      <span className="text-muted-foreground">{isSpeaking ? "Speaking detected" : "Listening..."}</span>
                    </div>
                  </div>
                )}

                <div className="mt-4">
                  {!isVoiceMaskActive ? (
                    <Button
                      onClick={() => startVoiceMask(currentVoiceType)}
                      className="w-full bg-success hover:bg-success/90"
                    >
                      <Mic className="mr-2 h-4 w-4" />
                      Activate Voice Mask
                    </Button>
                  ) : (
                    <Button onClick={stopVoiceMask} className="w-full bg-transparent" variant="outline">
                      <MicOff className="mr-2 h-4 w-4" />
                      Deactivate Voice Mask
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Voice Options */}
        <Card>
          <CardHeader>
            <CardTitle>Voice Types</CardTitle>
            <CardDescription>Choose how you want to sound</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {voiceOptions.map((voice) => {
              const Icon = voice.icon
              const isSelected = currentVoiceType === voice.id

              return (
                <button
                  key={voice.id}
                  onClick={() => changeVoiceType(voice.id)}
                  disabled={isVoiceMaskActive}
                  className={`w-full p-4 rounded-lg border-2 transition-all ${
                    isSelected
                      ? "border-success bg-success/5"
                      : "border-border hover:border-success/50 hover:bg-success/5"
                  } ${isVoiceMaskActive ? "opacity-50 cursor-not-allowed" : "cursor-pointer"}`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`rounded-full p-2 ${isSelected ? "bg-success/20" : "bg-muted"}`}>
                      <Icon className={`h-5 w-5 ${isSelected ? "text-success" : "text-muted-foreground"}`} />
                    </div>
                    <div className="flex-1 text-left">
                      <h3 className="font-medium">{voice.name}</h3>
                      <p className="text-sm text-muted-foreground">{voice.description}</p>
                    </div>
                    {isSelected && <div className="w-2 h-2 rounded-full bg-success animate-pulse" />}
                  </div>
                </button>
              )
            })}
          </CardContent>
        </Card>

        {/* Use Cases */}
        <Card className="border-warning bg-warning/5">
          <CardContent className="pt-6">
            <div className="flex gap-3">
              <AlertCircle className="h-5 w-5 text-warning flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-medium mb-2">When to Use Voice Mask</h3>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>• Calling someone while being followed to sound intimidating</li>
                  <li>• Pretending to talk to police or male guardian to scare attacker</li>
                  <li>• Protecting your identity in dangerous situations</li>
                  <li>• Making fake calls that sound more convincing and authoritative</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* How It Works */}
        <Card>
          <CardHeader>
            <CardTitle>How Voice Mask Works</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-3">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-semibold">
                1
              </div>
              <div>
                <h3 className="font-medium">Select Voice Type</h3>
                <p className="text-sm text-muted-foreground">
                  Choose how you want to sound - police officer, male adult, or deep rough voice
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-semibold">
                2
              </div>
              <div>
                <h3 className="font-medium">Activate Voice Mask</h3>
                <p className="text-sm text-muted-foreground">
                  Start the voice modification - your microphone will process your voice in real-time
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-semibold">
                3
              </div>
              <div>
                <h3 className="font-medium">Speak Confidently</h3>
                <p className="text-sm text-muted-foreground">
                  Your voice will be transformed to sound stronger, deeper, and more authoritative
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-semibold">
                4
              </div>
              <div>
                <h3 className="font-medium">Deter Attackers</h3>
                <p className="text-sm text-muted-foreground">
                  Use your modified voice to pretend you're talking to police or sound intimidating
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
