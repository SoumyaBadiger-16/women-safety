import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { to, subject, message, location } = await request.json()

    // Check if email credentials are configured
    const emailUser = process.env.EMAIL_USER
    const emailPass = process.env.EMAIL_PASSWORD

    if (!emailUser || !emailPass) {
      console.log("[v0] Email not configured - Email would be sent:", { to, subject })
      return NextResponse.json({
        success: true,
        message: "Email would be sent (SMTP not configured in demo)",
      })
    }

    // Send email using nodemailer
    const nodemailer = require("nodemailer")

    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: emailUser,
        pass: emailPass,
      },
    })

    const mailOptions = {
      from: emailUser,
      to: to,
      subject: subject,
      html: `
        <div style="font-family: Arial, sans-serif; padding: 20px; background-color: #fee; border: 2px solid #c00;">
          <h1 style="color: #c00;">🚨 EMERGENCY ALERT</h1>
          <p style="font-size: 16px;">${message.replace(/\n/g, "<br>")}</p>
          ${
            location
              ? `
            <p><strong>Location:</strong></p>
            <a href="https://maps.google.com/?q=${location.latitude},${location.longitude}" style="display: inline-block; padding: 10px 20px; background-color: #c00; color: white; text-decoration: none; border-radius: 5px;">
              View Location on Map
            </a>
          `
              : ""
          }
          <p style="margin-top: 20px; font-size: 12px; color: #666;">
            This is an automated emergency alert from ProtectMe Safety App.
          </p>
        </div>
      `,
    }

    const info = await transporter.sendMail(mailOptions)

    console.log("[v0] Email sent successfully:", info.messageId)

    return NextResponse.json({ success: true, messageId: info.messageId })
  } catch (error) {
    console.error("[v0] Email send error:", error)
    return NextResponse.json({ error: "Failed to send email" }, { status: 500 })
  }
}
