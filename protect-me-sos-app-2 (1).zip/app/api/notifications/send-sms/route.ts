import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { to, message } = await request.json()

    // Check if Twilio credentials are configured
    const accountSid = process.env.TWILIO_ACCOUNT_SID
    const authToken = process.env.TWILIO_AUTH_TOKEN
    const fromNumber = process.env.TWILIO_PHONE_NUMBER

    if (!accountSid || !authToken || !fromNumber) {
      console.log("[v0] Twilio not configured - SMS would be sent:", { to, message: message.substring(0, 50) + "..." })
      return NextResponse.json({
        success: true,
        message: "SMS would be sent (Twilio not configured in demo)",
      })
    }

    // Send SMS using Twilio
    const twilio = require("twilio")(accountSid, authToken)

    const result = await twilio.messages.create({
      body: message,
      from: fromNumber,
      to: to,
    })

    console.log("[v0] SMS sent successfully:", result.sid)

    return NextResponse.json({ success: true, sid: result.sid })
  } catch (error) {
    console.error("[v0] SMS send error:", error)
    return NextResponse.json({ error: "Failed to send SMS" }, { status: 500 })
  }
}
