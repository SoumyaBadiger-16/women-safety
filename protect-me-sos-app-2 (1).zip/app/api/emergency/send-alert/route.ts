import { type NextRequest, NextResponse } from "next/server"
import { createServerClient } from "@/lib/supabase/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = await createServerClient()
    const body = await request.json()

    const { location, message, alertType, userId } = body

    console.log("[v0] Emergency alert triggered:", { alertType, userId })

    // Get user's emergency contacts from database
    const { data: contacts, error: contactsError } = await supabase
      .from("contacts")
      .select("*")
      .eq("user_id", userId)
      .eq("notify_on_sos", true)

    if (contactsError) {
      console.error("[v0] Error fetching contacts:", contactsError)
      return NextResponse.json({ error: "Failed to fetch contacts" }, { status: 500 })
    }

    if (!contacts || contacts.length === 0) {
      return NextResponse.json({ error: "No emergency contacts configured" }, { status: 400 })
    }

    // Create SOS alert record in database
    const { data: alert, error: alertError } = await supabase
      .from("sos_alerts")
      .insert({
        user_id: userId,
        latitude: location?.latitude,
        longitude: location?.longitude,
        alert_type: alertType || "manual",
        message: message || "Emergency SOS triggered",
        status: "active",
      })
      .select()
      .single()

    if (alertError) {
      console.error("[v0] Error creating alert:", alertError)
      return NextResponse.json({ error: "Failed to create alert" }, { status: 500 })
    }

    // Send SMS and emails to all emergency contacts
    const notificationPromises = contacts.map(async (contact) => {
      const emergencyMessage = `🚨 EMERGENCY ALERT from ${contact.name}!\n\n${message || "SOS triggered"}\n\nLocation: ${location ? `https://maps.google.com/?q=${location.latitude},${location.longitude}` : "Location unavailable"}\n\nThis is an automated emergency alert from ProtectMe.`

      // Send SMS if phone number exists
      if (contact.phone) {
        try {
          await fetch(`${request.nextUrl.origin}/api/notifications/send-sms`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              to: contact.phone,
              message: emergencyMessage,
            }),
          })
          console.log(`[v0] SMS sent to ${contact.phone}`)
        } catch (error) {
          console.error(`[v0] Failed to send SMS to ${contact.phone}:`, error)
        }
      }

      // Send email if email exists
      if (contact.email) {
        try {
          await fetch(`${request.nextUrl.origin}/api/notifications/send-email`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              to: contact.email,
              subject: "🚨 EMERGENCY ALERT",
              message: emergencyMessage,
              location,
            }),
          })
          console.log(`[v0] Email sent to ${contact.email}`)
        } catch (error) {
          console.error(`[v0] Failed to send email to ${contact.email}:`, error)
        }
      }
    })

    await Promise.all(notificationPromises)

    return NextResponse.json({
      success: true,
      alertId: alert.id,
      contactsNotified: contacts.length,
    })
  } catch (error) {
    console.error("[v0] Emergency alert error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
